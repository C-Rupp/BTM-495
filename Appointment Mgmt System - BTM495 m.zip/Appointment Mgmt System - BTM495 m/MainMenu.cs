using System;
using Microsoft.Data.SqlClient; // Use the new namespace
using System.Windows.Forms;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormMainMenu : Form
    {
        public string email;

        public FormMainMenu(string email)
        {
            InitializeComponent();
            this.email = email;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddAppoinment form2 = new AddAppoinment();
            form2.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Created by accident, don't delete or it will cause errors
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Search_Click(object sender, EventArgs e)
        {
            string firstName = sfirst.Text.Trim();
            string lastName = slast.Text.Trim();

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
            {
                MessageBox.Show("Please enter both first name and last name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            

            SearchParticipants(firstName, lastName);
        }

        private void SearchParticipants(string firstName, string lastName)
        {
            string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM 495 DB\";Integrated Security=True;Trust Server Certificate=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT p.participantID, u.userID, u.FirstName, u.LastName, p.gender, p.dateOfBirth
                        FROM [BTM 495 DB].[dbo].[Participant] p
                        JOIN [BTM 495 DB].[dbo].[Users] u ON p.userID = u.userID
                        WHERE u.FirstName = @FirstName AND u.LastName = @LastName";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@FirstName", firstName);
                        command.Parameters.AddWithValue("@LastName", lastName);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                // Store results in a string to display in the message box
                                string results = "Search Results:\n";

                                while (reader.Read())
                                {
                                    string participantId = reader["participantID"].ToString();
                                    string userId = reader["userID"].ToString();
                                    string fName = reader["FirstName"].ToString();
                                    string lName = reader["LastName"].ToString();
                                    string gender = reader["gender"].ToString();
                                    string dateOfBirth = reader["dateOfBirth"].ToString();

                                    results += $"ParticipantID: {participantId}, UserID: {userId}, First Name: {fName}, Last Name: {lName}, Gender: {gender}, Date of Birth: {dateOfBirth}\n";
                                }

                                MessageBox.Show(results, "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("No participants found with the provided first and last name.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

       
    }
}
