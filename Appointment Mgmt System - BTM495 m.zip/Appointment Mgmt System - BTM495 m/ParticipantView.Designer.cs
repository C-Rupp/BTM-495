﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class FormParticipantView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            btnCancelAppt = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(239, 188);
            button1.Name = "button1";
            button1.Size = new Size(0, 0);
            button1.TabIndex = 0;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnCancelAppt
            // 
            btnCancelAppt.BackColor = Color.FromArgb(237, 27, 47);
            btnCancelAppt.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCancelAppt.ForeColor = SystemColors.Control;
            btnCancelAppt.Location = new Point(72, 60);
            btnCancelAppt.Name = "btnCancelAppt";
            btnCancelAppt.Size = new Size(266, 55);
            btnCancelAppt.TabIndex = 5;
            btnCancelAppt.Text = "Cancel Appointment";
            btnCancelAppt.UseVisualStyleBackColor = false;
            btnCancelAppt.Click += btnCancelAppt_Click;
            // 
            // FormParticipantView
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1767, 911);
            Controls.Add(btnCancelAppt);
            Controls.Add(button1);
            Name = "FormParticipantView";
            Text = "Participant Home";
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button btnCancelAppt;
    }
}