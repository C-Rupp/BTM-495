﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class AddAppoinment
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnSubmit = new Button();
            txtUserID = new TextBox();
            txtRoom = new TextBox();
            txtDetail = new TextBox();
            lblUserID = new Label();
            lblAppointmentStart = new Label();
            lblAppointmentEnd = new Label();
            lblRoom = new Label();
            lblDetail = new Label();
            dtpAppointmentStart = new DateTimePicker();
            dtpAppointmentEnd = new DateTimePicker();
            SuspendLayout();
            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(124, 288);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(206, 29);
            btnSubmit.TabIndex = 8;
            btnSubmit.Text = "Add Appointment";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtUserID
            // 
            txtUserID.Location = new Point(167, 53);
            txtUserID.Name = "txtUserID";
            txtUserID.Size = new Size(125, 27);
            txtUserID.TabIndex = 1;
            // 
            // txtRoom
            // 
            txtRoom.Location = new Point(167, 150);
            txtRoom.Name = "txtRoom";
            txtRoom.Size = new Size(125, 27);
            txtRoom.TabIndex = 2;
            // 
            // txtDetail
            // 
            txtDetail.Location = new Point(167, 183);
            txtDetail.Name = "txtDetail";
            txtDetail.Size = new Size(125, 27);
            txtDetail.TabIndex = 3;
            // 
            // lblUserID
            // 
            lblUserID.AutoSize = true;
            lblUserID.Location = new Point(104, 56);
            lblUserID.Name = "lblUserID";
            lblUserID.Size = new Size(57, 20);
            lblUserID.TabIndex = 19;
            lblUserID.Text = "User ID";
            // 
            // lblAppointmentStart
            // 
            lblAppointmentStart.AutoSize = true;
            lblAppointmentStart.Location = new Point(3, 89);
            lblAppointmentStart.Name = "lblAppointmentStart";
            lblAppointmentStart.Size = new Size(168, 20);
            lblAppointmentStart.TabIndex = 11;
            lblAppointmentStart.Text = "Appointment Date Start";
            // 
            // lblAppointmentEnd
            // 
            lblAppointmentEnd.AutoSize = true;
            lblAppointmentEnd.Location = new Point(12, 120);
            lblAppointmentEnd.Name = "lblAppointmentEnd";
            lblAppointmentEnd.Size = new Size(162, 20);
            lblAppointmentEnd.TabIndex = 12;
            lblAppointmentEnd.Text = "Appointment Date End";
            // 
            // lblRoom
            // 
            lblRoom.AutoSize = true;
            lblRoom.Location = new Point(112, 153);
            lblRoom.Name = "lblRoom";
            lblRoom.Size = new Size(49, 20);
            lblRoom.TabIndex = 10;
            lblRoom.Text = "Room";
            // 
            // lblDetail
            // 
            lblDetail.AutoSize = true;
            lblDetail.Location = new Point(112, 186);
            lblDetail.Name = "lblDetail";
            lblDetail.Size = new Size(49, 20);
            lblDetail.TabIndex = 13;
            lblDetail.Text = "Detail";
            // 
            // dtpAppointmentStart
            // 
            dtpAppointmentStart.CustomFormat = "dd/MM/yyyy HH:mm";
            dtpAppointmentStart.Format = DateTimePickerFormat.Custom;
            dtpAppointmentStart.Location = new Point(167, 86);
            dtpAppointmentStart.Name = "dtpAppointmentStart";
            dtpAppointmentStart.ShowUpDown = true;
            dtpAppointmentStart.Size = new Size(250, 27);
            dtpAppointmentStart.TabIndex = 17;
            // 
            // dtpAppointmentEnd
            // 
            dtpAppointmentEnd.CustomFormat = "dd/MM/yyyy HH:mm";
            dtpAppointmentEnd.Format = DateTimePickerFormat.Custom;
            dtpAppointmentEnd.Location = new Point(167, 117);
            dtpAppointmentEnd.Name = "dtpAppointmentEnd";
            dtpAppointmentEnd.ShowUpDown = true;
            dtpAppointmentEnd.Size = new Size(250, 27);
            dtpAppointmentEnd.TabIndex = 18;
            // 
            // AddAppoinment
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblUserID);
            Controls.Add(dtpAppointmentEnd);
            Controls.Add(dtpAppointmentStart);
            Controls.Add(lblDetail);
            Controls.Add(lblAppointmentEnd);
            Controls.Add(lblAppointmentStart);
            Controls.Add(lblRoom);
            Controls.Add(btnSubmit);
            Controls.Add(txtDetail);
            Controls.Add(txtRoom);
            Controls.Add(txtUserID);
            Name = "AddAppoinment";
            Text = "Appointment Form";
            Load += AddAppoinment_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private TextBox txtUserID;
        private TextBox txtRoom;
        private TextBox txtDetail;
        private Button btnSubmit;
        private Label lblUserID;
        private Label lblAppointmentStart;
        private Label lblAppointmentEnd;
        private Label lblRoom;
        private Label lblDetail;
        private DateTimePicker dtpAppointmentStart;
        private DateTimePicker dtpAppointmentEnd;
    }
}
