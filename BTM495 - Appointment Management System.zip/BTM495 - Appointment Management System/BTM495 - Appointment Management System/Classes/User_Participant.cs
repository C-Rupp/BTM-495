﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTM495___Appointment_Management_System.Classes
{
    public class Participant : User
    {
        public int ParticipantID { get; set; }
        public decimal Weight { get; set; }
        public decimal Height { get; set; }
        public required string EmergencyContactName { get; set; }
        public required string EmergencyContactPhone { get; set; }
        public required Boolean EligiblityStatus { get; set; }

    }
}
