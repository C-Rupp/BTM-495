﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTM495___Appointment_Management_System.Classes
{
    public class Database_Handler
    {
    }
}
