﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace BTM495___Appointment_Management_System.Classes
{
    public class Appointment
    {
        public int AppointmentID { get; set; }
        public required string AppointmentDate { get; set; }
        public required string AppointmentTimeFrom { get; set; }
        public required string AppointmentTimeTo { get; set; }
        public required string Room { get; set; }
        public required string Detail { get; set; }
        public required string CancellationDate { get; set; }
    }
}
