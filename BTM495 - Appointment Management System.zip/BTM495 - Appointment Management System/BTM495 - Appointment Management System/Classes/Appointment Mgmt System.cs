﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTM495___Appointment_Management_System.Classes
{
    public class Appointment_Mgmt_System
    {
        public required string currentTime { get; set; }
        public required string differenceTime { get; set; }
        public required string currentDate { get; set; }
        public required string differenceDate { get; set; }
        public required Appointment Appointment { get; set; } //Navigation Property
        public required User User { get; set; } //Navigation Property
    }
}
