﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class FormAddAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSubmit = new Button();
            txtUserID = new TextBox();
            lblUserID = new Label();
            lblRoom = new Label();
            txtRoom = new TextBox();
            lblAppointmenttStart = new Label();
            dtpAppointmentStart = new DateTimePicker();
            dtpAppointmentEnd = new DateTimePicker();
            lblAppointmentEnd = new Label();
            lblDetail = new Label();
            txtDetail = new TextBox();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pbMenuBar = new PictureBox();
            btnHome = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).BeginInit();
            SuspendLayout();
            // 
            // btnSubmit
            // 
            btnSubmit.BackColor = Color.FromArgb(237, 27, 47);
            btnSubmit.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSubmit.ForeColor = SystemColors.Control;
            btnSubmit.Location = new Point(537, 611);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(344, 42);
            btnSubmit.TabIndex = 2;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = false;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtUserID
            // 
            txtUserID.Location = new Point(137, 159);
            txtUserID.Name = "txtUserID";
            txtUserID.Size = new Size(226, 23);
            txtUserID.TabIndex = 3;
            // 
            // lblUserID
            // 
            lblUserID.AutoSize = true;
            lblUserID.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUserID.ForeColor = Color.Black;
            lblUserID.Location = new Point(137, 113);
            lblUserID.Name = "lblUserID";
            lblUserID.Size = new Size(65, 21);
            lblUserID.TabIndex = 5;
            lblUserID.Text = "User ID";
            // 
            // lblRoom
            // 
            lblRoom.AutoSize = true;
            lblRoom.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRoom.ForeColor = Color.Black;
            lblRoom.Location = new Point(137, 241);
            lblRoom.Name = "lblRoom";
            lblRoom.Size = new Size(55, 21);
            lblRoom.TabIndex = 7;
            lblRoom.Text = "Room";
            // 
            // txtRoom
            // 
            txtRoom.Location = new Point(137, 287);
            txtRoom.Name = "txtRoom";
            txtRoom.Size = new Size(226, 23);
            txtRoom.TabIndex = 6;
            // 
            // lblAppointmenttStart
            // 
            lblAppointmenttStart.AutoSize = true;
            lblAppointmenttStart.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAppointmenttStart.ForeColor = Color.Black;
            lblAppointmenttStart.Location = new Point(584, 113);
            lblAppointmenttStart.Name = "lblAppointmenttStart";
            lblAppointmenttStart.Size = new Size(152, 21);
            lblAppointmenttStart.TabIndex = 9;
            lblAppointmenttStart.Text = "Appointment Start";
            // 
            // dtpAppointmentStart
            // 
            dtpAppointmentStart.Location = new Point(584, 159);
            dtpAppointmentStart.Name = "dtpAppointmentStart";
            dtpAppointmentStart.Size = new Size(226, 23);
            dtpAppointmentStart.TabIndex = 10;
            // 
            // dtpAppointmentEnd
            // 
            dtpAppointmentEnd.Location = new Point(584, 287);
            dtpAppointmentEnd.Name = "dtpAppointmentEnd";
            dtpAppointmentEnd.Size = new Size(226, 23);
            dtpAppointmentEnd.TabIndex = 12;
            // 
            // lblAppointmentEnd
            // 
            lblAppointmentEnd.AutoSize = true;
            lblAppointmentEnd.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAppointmentEnd.ForeColor = Color.Black;
            lblAppointmentEnd.Location = new Point(584, 241);
            lblAppointmentEnd.Name = "lblAppointmentEnd";
            lblAppointmentEnd.Size = new Size(145, 21);
            lblAppointmentEnd.TabIndex = 11;
            lblAppointmentEnd.Text = "Appointment End";
            // 
            // lblDetail
            // 
            lblDetail.AutoSize = true;
            lblDetail.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDetail.ForeColor = Color.Black;
            lblDetail.Location = new Point(1030, 113);
            lblDetail.Name = "lblDetail";
            lblDetail.Size = new Size(56, 21);
            lblDetail.TabIndex = 13;
            lblDetail.Text = "Detail";
            // 
            // txtDetail
            // 
            txtDetail.Location = new Point(1030, 159);
            txtDetail.Name = "txtDetail";
            txtDetail.Size = new Size(226, 23);
            txtDetail.TabIndex = 14;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(237, 27, 47);
            label1.Font = new Font("Garamond", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(28, 9);
            label1.Name = "label1";
            label1.Size = new Size(93, 30);
            label1.TabIndex = 18;
            label1.Text = "McGill";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(237, 27, 47);
            pictureBox2.Location = new Point(-1, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(153, 49);
            pictureBox2.TabIndex = 17;
            pictureBox2.TabStop = false;
            // 
            // pbMenuBar
            // 
            pbMenuBar.BackColor = Color.Black;
            pbMenuBar.Location = new Point(-1, 0);
            pbMenuBar.Name = "pbMenuBar";
            pbMenuBar.Size = new Size(1412, 49);
            pbMenuBar.TabIndex = 16;
            pbMenuBar.TabStop = false;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(237, 27, 47);
            btnHome.FlatStyle = FlatStyle.Popup;
            btnHome.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHome.ForeColor = SystemColors.Control;
            btnHome.Location = new Point(1320, 0);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(91, 49);
            btnHome.TabIndex = 50;
            btnHome.Text = "Home";
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // FormAddAppointment
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1410, 721);
            Controls.Add(btnHome);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pbMenuBar);
            Controls.Add(txtDetail);
            Controls.Add(lblDetail);
            Controls.Add(dtpAppointmentEnd);
            Controls.Add(lblAppointmentEnd);
            Controls.Add(dtpAppointmentStart);
            Controls.Add(lblAppointmenttStart);
            Controls.Add(lblRoom);
            Controls.Add(txtRoom);
            Controls.Add(lblUserID);
            Controls.Add(txtUserID);
            Controls.Add(btnSubmit);
            Name = "FormAddAppointment";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Add Appointment Page";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSubmit;
        private TextBox txtUserID;
        public Label lblUserID;
        public Label lblRoom;
        private TextBox txtRoom;
        public Label lblAppointmenttStart;
        private DateTimePicker dtpAppointmentStart;
        private DateTimePicker dtpAppointmentEnd;
        public Label lblAppointmentEnd;
        public Label lblDetail;
        private TextBox txtDetail;
        public Label label1;
        private PictureBox pictureBox2;
        private PictureBox pbMenuBar;
        private Button btnHome;
    }
}