﻿namespace Appointment_Mgmt_System___BTM495
{
    public class LabCoordinator : User
    {
        public LabCoordinator(int userID, string firstName, string lastName, string email)
            : base(userID, firstName, lastName, email)
        {
        }
    }
}
