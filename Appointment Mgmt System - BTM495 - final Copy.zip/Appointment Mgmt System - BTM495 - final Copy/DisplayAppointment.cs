﻿using Microsoft.Data.SqlClient;
using System;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormDisplayAppointment : Form
    {
        public FormDisplayAppointment()
        {
            InitializeComponent();
            SelectSpecificMonthandYear();
            InitializeListView();
        }

        public void SelectSpecificMonthandYear()
        {
            // Make sure the combo box exists and is properly named
            if (cmbBoxMonth != null)
            {
                cmbBoxMonth.Items.AddRange(new string[]
                {
                    "January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"
                });
            }
        }

        private void InitializeListView()
        {
            // Ensure the ListView control exists
            if (lstAppointments != null)
            {
                lstAppointments.View = View.Details;
                lstAppointments.FullRowSelect = true;
                lstAppointments.Columns.Add("First Name");
                lstAppointments.Columns.Add("Last Name");
                lstAppointments.Columns.Add("Appointment Date Start");
                lstAppointments.Columns.Add("Appointment Date End");
                lstAppointments.Columns.Add("Status");
                lstAppointments.Columns.Add("Cancellation Date");
            }
        }

        private void cmbBoxMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbBoxMonth.SelectedItem != null)
            {
                MessageBox.Show($"You selected: {cmbBoxMonth.SelectedItem}");
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            // Navigate back to the main menu
            FormMainMenu mainMenu = new FormMainMenu(null); // Pass null or modify constructor to not require an email
            mainMenu.Show(); // Show the main menu
            this.Close(); // Close the current form
        }

        private void btnDisplayAppointment_Click(object sender, EventArgs e)
        {
            if (cmbBoxMonth.SelectedItem == null || string.IsNullOrWhiteSpace(txtBoxYear.Text))
            {
                MessageBox.Show("Please select a month and enter a year.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Convert month name to number
            int month = cmbBoxMonth.SelectedIndex + 1;

            // Parse year input
            if (!int.TryParse(txtBoxYear.Text, out int year))
            {
                MessageBox.Show("Please enter a valid numeric year.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Fetch data from the database
            RequestSpecificMonthandYear(month, year);
        }

        private void RequestSpecificMonthandYear(int month, int year)
        {
            string connectionString = "Data Source = J_inspiration_1\\SQLEXPRESS; Initial Catalog =\"BTM495 DB\";Integrated Security=True;Trust Server Certificate=True;";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // SQL Query to fetch data
                    string query = @"
                        SELECT 
                            u.FirstName, 
                            u.LastName, 
                            a.AppointmentDateStart,
                            a.AppointmentDateEnd,
                            a.Status,
                            a.CancellationDate,
                            DATEDIFF(MONTH, GETDATE(), a.AppointmentDateStart) AS dateDiff
                        FROM 
                            [BTM495 DB].[dbo].[Users] u
                        INNER JOIN 
                            [BTM495 DB].[dbo].[Appointment] a ON u.UserID = a.UserID
                        WHERE 
                            MONTH(a.AppointmentDateStart) = @Month AND 
                            YEAR(a.AppointmentDateStart) = @Year
                        ORDER BY 
                            a.AppointmentDateStart ASC"; // Sort ascending by appointment date start

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Month", month);
                        command.Parameters.AddWithValue("@Year", year);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Clear previous results
                            lstAppointments.Items.Clear();

                            // Read results
                            while (reader.Read())
                            {
                                ListViewItem item = new ListViewItem(reader["FirstName"].ToString());
                                item.SubItems.Add(reader["LastName"].ToString());
                                item.SubItems.Add(Convert.ToDateTime(reader["AppointmentDateStart"]).ToString("yyyy-MM-dd HH:mm")); // Format to exclude seconds
                                item.SubItems.Add(Convert.ToDateTime(reader["AppointmentDateEnd"]).ToString("yyyy-MM-dd HH:mm")); // Format to exclude seconds
                                item.SubItems.Add(reader["Status"].ToString());
                                item.SubItems.Add(reader["CancellationDate"].ToString());

                                lstAppointments.Items.Add(item);
                            }

                            // Adjust column widths to fit content
                            foreach (ColumnHeader column in lstAppointments.Columns)
                            {
                                column.Width = -2; // Auto-size the columns
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static TextBox GetTxtBoxYear(TextBox txtBoxYear) => txtBoxYear;

        private static void TxtBoxYear_TextChanged1(object sender, EventArgs e, TextBox txtBoxYear)
        {
            // Check if the input is valid as the user types
            if (!string.IsNullOrWhiteSpace(txtBoxYear.Text) && !int.TryParse(txtBoxYear.Text, out _))
            {
                MessageBox.Show("Please enter only numeric values for the year.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBoxYear.Text = string.Empty;
            }
        }
    }
}
