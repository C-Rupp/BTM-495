﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class FormCreateProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pbMenuBar = new PictureBox();
            lblEmergencyContactPhone = new Label();
            txtEmergencyContactPhone = new TextBox();
            lblEmergencyContactName = new Label();
            txtEmergencyContactName = new TextBox();
            lblHeight = new Label();
            txtHeight = new TextBox();
            lbGender = new Label();
            txtGender = new TextBox();
            lblWeight = new Label();
            txtWeight = new TextBox();
            txtConfirmPassword = new TextBox();
            lblConfirmPassword = new Label();
            lblParticipantInformation = new Label();
            pictureBox3 = new PictureBox();
            pictureBox1 = new PictureBox();
            txtPassword = new TextBox();
            txtLastName = new TextBox();
            lblDateOfBirth = new Label();
            dtpDateOfBirth = new DateTimePicker();
            lblPassword = new Label();
            lblLastName = new Label();
            lblEmail = new Label();
            txtEmail = new TextBox();
            lblFirstName = new Label();
            txtFirstName = new TextBox();
            btnCreateProfile = new Button();
            btnLogin = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(237, 27, 47);
            label1.Font = new Font("Garamond", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(28, 9);
            label1.Name = "label1";
            label1.Size = new Size(93, 30);
            label1.TabIndex = 16;
            label1.Text = "McGill";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(237, 27, 47);
            pictureBox2.Location = new Point(-1, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(153, 49);
            pictureBox2.TabIndex = 15;
            pictureBox2.TabStop = false;
            // 
            // pbMenuBar
            // 
            pbMenuBar.BackColor = Color.Black;
            pbMenuBar.Location = new Point(-1, 0);
            pbMenuBar.Name = "pbMenuBar";
            pbMenuBar.Size = new Size(1412, 49);
            pbMenuBar.TabIndex = 14;
            pbMenuBar.TabStop = false;
            // 
            // lblEmergencyContactPhone
            // 
            lblEmergencyContactPhone.AutoSize = true;
            lblEmergencyContactPhone.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEmergencyContactPhone.ForeColor = Color.Black;
            lblEmergencyContactPhone.Location = new Point(599, 477);
            lblEmergencyContactPhone.Name = "lblEmergencyContactPhone";
            lblEmergencyContactPhone.Size = new Size(211, 21);
            lblEmergencyContactPhone.TabIndex = 70;
            lblEmergencyContactPhone.Text = "Emergency Contact Phone";
            // 
            // txtEmergencyContactPhone
            // 
            txtEmergencyContactPhone.Location = new Point(599, 523);
            txtEmergencyContactPhone.Name = "txtEmergencyContactPhone";
            txtEmergencyContactPhone.Size = new Size(226, 23);
            txtEmergencyContactPhone.TabIndex = 69;
            // 
            // lblEmergencyContactName
            // 
            lblEmergencyContactName.AutoSize = true;
            lblEmergencyContactName.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEmergencyContactName.ForeColor = Color.Black;
            lblEmergencyContactName.Location = new Point(153, 477);
            lblEmergencyContactName.Name = "lblEmergencyContactName";
            lblEmergencyContactName.Size = new Size(208, 21);
            lblEmergencyContactName.TabIndex = 68;
            lblEmergencyContactName.Text = "Emergency Contact Name";
            // 
            // txtEmergencyContactName
            // 
            txtEmergencyContactName.Location = new Point(153, 523);
            txtEmergencyContactName.Name = "txtEmergencyContactName";
            txtEmergencyContactName.Size = new Size(226, 23);
            txtEmergencyContactName.TabIndex = 67;
            // 
            // lblHeight
            // 
            lblHeight.AutoSize = true;
            lblHeight.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHeight.ForeColor = Color.Black;
            lblHeight.Location = new Point(1056, 477);
            lblHeight.Name = "lblHeight";
            lblHeight.Size = new Size(101, 21);
            lblHeight.TabIndex = 66;
            lblHeight.Text = "Height (cm)";
            // 
            // txtHeight
            // 
            txtHeight.Location = new Point(1056, 523);
            txtHeight.Name = "txtHeight";
            txtHeight.Size = new Size(226, 23);
            txtHeight.TabIndex = 65;
            // 
            // lbGender
            // 
            lbGender.AutoSize = true;
            lbGender.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbGender.ForeColor = Color.Black;
            lbGender.Location = new Point(599, 364);
            lbGender.Name = "lbGender";
            lbGender.Size = new Size(65, 21);
            lbGender.TabIndex = 64;
            lbGender.Text = "Gender";
            // 
            // txtGender
            // 
            txtGender.Location = new Point(599, 410);
            txtGender.Name = "txtGender";
            txtGender.Size = new Size(226, 23);
            txtGender.TabIndex = 63;
            // 
            // lblWeight
            // 
            lblWeight.AutoSize = true;
            lblWeight.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblWeight.ForeColor = Color.Black;
            lblWeight.Location = new Point(1056, 364);
            lblWeight.Name = "lblWeight";
            lblWeight.Size = new Size(101, 21);
            lblWeight.TabIndex = 62;
            lblWeight.Text = "Weight (kg)";
            // 
            // txtWeight
            // 
            txtWeight.Location = new Point(1056, 410);
            txtWeight.Name = "txtWeight";
            txtWeight.Size = new Size(226, 23);
            txtWeight.TabIndex = 61;
            // 
            // txtConfirmPassword
            // 
            txtConfirmPassword.Location = new Point(1056, 243);
            txtConfirmPassword.Name = "txtConfirmPassword";
            txtConfirmPassword.PasswordChar = '*';
            txtConfirmPassword.Size = new Size(226, 23);
            txtConfirmPassword.TabIndex = 60;
            // 
            // lblConfirmPassword
            // 
            lblConfirmPassword.AutoSize = true;
            lblConfirmPassword.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblConfirmPassword.ForeColor = Color.Black;
            lblConfirmPassword.Location = new Point(1056, 197);
            lblConfirmPassword.Name = "lblConfirmPassword";
            lblConfirmPassword.Size = new Size(148, 21);
            lblConfirmPassword.TabIndex = 59;
            lblConfirmPassword.Text = "Confirm Password";
            // 
            // lblParticipantInformation
            // 
            lblParticipantInformation.AutoSize = true;
            lblParticipantInformation.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblParticipantInformation.ForeColor = Color.Black;
            lblParticipantInformation.Location = new Point(143, 296);
            lblParticipantInformation.Name = "lblParticipantInformation";
            lblParticipantInformation.Size = new Size(223, 25);
            lblParticipantInformation.TabIndex = 58;
            lblParticipantInformation.Text = "Participant Information";
            // 
            // pictureBox3
            // 
            pictureBox3.Location = new Point(5, 310);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(1412, 16);
            pictureBox3.TabIndex = 57;
            pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(-7, 322);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1424, 13);
            pictureBox1.TabIndex = 56;
            pictureBox1.TabStop = false;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(600, 243);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(226, 23);
            txtPassword.TabIndex = 55;
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(599, 126);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(226, 23);
            txtLastName.TabIndex = 54;
            // 
            // lblDateOfBirth
            // 
            lblDateOfBirth.AutoSize = true;
            lblDateOfBirth.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDateOfBirth.ForeColor = Color.Black;
            lblDateOfBirth.Location = new Point(152, 364);
            lblDateOfBirth.Name = "lblDateOfBirth";
            lblDateOfBirth.Size = new Size(107, 21);
            lblDateOfBirth.TabIndex = 53;
            lblDateOfBirth.Text = "Date of Birth";
            // 
            // dtpDateOfBirth
            // 
            dtpDateOfBirth.Location = new Point(152, 410);
            dtpDateOfBirth.Name = "dtpDateOfBirth";
            dtpDateOfBirth.Size = new Size(226, 23);
            dtpDateOfBirth.TabIndex = 52;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPassword.ForeColor = Color.Black;
            lblPassword.Location = new Point(600, 197);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(82, 21);
            lblPassword.TabIndex = 51;
            lblPassword.Text = "Password";
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLastName.ForeColor = Color.Black;
            lblLastName.Location = new Point(599, 80);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(90, 21);
            lblLastName.TabIndex = 50;
            lblLastName.Text = "Last Name";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEmail.ForeColor = Color.Black;
            lblEmail.Location = new Point(153, 197);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(53, 21);
            lblEmail.TabIndex = 49;
            lblEmail.Text = "Email";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(153, 243);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(226, 23);
            txtEmail.TabIndex = 48;
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFirstName.ForeColor = Color.Black;
            lblFirstName.Location = new Point(152, 80);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(92, 21);
            lblFirstName.TabIndex = 47;
            lblFirstName.Text = "First Name";
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(152, 126);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(226, 23);
            txtFirstName.TabIndex = 46;
            // 
            // btnCreateProfile
            // 
            btnCreateProfile.BackColor = Color.FromArgb(237, 27, 47);
            btnCreateProfile.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCreateProfile.ForeColor = SystemColors.Control;
            btnCreateProfile.Location = new Point(549, 598);
            btnCreateProfile.Name = "btnCreateProfile";
            btnCreateProfile.Size = new Size(344, 42);
            btnCreateProfile.TabIndex = 45;
            btnCreateProfile.Text = "Create Profile";
            btnCreateProfile.UseVisualStyleBackColor = false;
            btnCreateProfile.Click += btnCreateProfile_Click;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.FromArgb(237, 27, 47);
            btnLogin.FlatStyle = FlatStyle.Popup;
            btnLogin.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogin.ForeColor = SystemColors.Control;
            btnLogin.Location = new Point(1320, 0);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(91, 49);
            btnLogin.TabIndex = 71;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // FormCreateProfile
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1410, 721);
            Controls.Add(btnLogin);
            Controls.Add(lblEmergencyContactPhone);
            Controls.Add(txtEmergencyContactPhone);
            Controls.Add(lblEmergencyContactName);
            Controls.Add(txtEmergencyContactName);
            Controls.Add(lblHeight);
            Controls.Add(txtHeight);
            Controls.Add(lbGender);
            Controls.Add(txtGender);
            Controls.Add(lblWeight);
            Controls.Add(txtWeight);
            Controls.Add(txtConfirmPassword);
            Controls.Add(lblConfirmPassword);
            Controls.Add(lblParticipantInformation);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox1);
            Controls.Add(txtPassword);
            Controls.Add(txtLastName);
            Controls.Add(lblDateOfBirth);
            Controls.Add(dtpDateOfBirth);
            Controls.Add(lblPassword);
            Controls.Add(lblLastName);
            Controls.Add(lblEmail);
            Controls.Add(txtEmail);
            Controls.Add(lblFirstName);
            Controls.Add(txtFirstName);
            Controls.Add(btnCreateProfile);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pbMenuBar);
            Name = "FormCreateProfile";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Participant Profile Creation";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        public Label label1;
        private PictureBox pictureBox2;
        private PictureBox pbMenuBar;
        public Label lblEmergencyContactPhone;
        private TextBox txtEmergencyContactPhone;
        public Label lblEmergencyContactName;
        private TextBox txtEmergencyContactName;
        public Label lblHeight;
        private TextBox txtHeight;
        public Label lbGender;
        private TextBox txtGender;
        public Label lblWeight;
        private TextBox txtWeight;
        private TextBox txtConfirmPassword;
        public Label lblConfirmPassword;
        public Label lblParticipantInformation;
        private PictureBox pictureBox3;
        private PictureBox pictureBox1;
        private TextBox txtPassword;
        private TextBox txtLastName;
        public Label lblDateOfBirth;
        private DateTimePicker dtpDateOfBirth;
        public Label lblPassword;
        public Label lblLastName;
        public Label lblEmail;
        private TextBox txtEmail;
        public Label lblFirstName;
        private TextBox txtFirstName;
        private Button btnCreateProfile;
        private Button btnLogin;
    }
}