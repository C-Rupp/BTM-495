﻿using Microsoft.Data.SqlClient;
using System;
using System.Windows.Forms;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormCancelAppointment : Form
    {
        private string participantEmail; // Store the email entered by the lab coordinator or participant
        private int participantUserID; // Store the participant's userID after fetching from the database
        private DateTime appointmentDateStart; // Store the appointment start date

        public FormCancelAppointment()
        {
            InitializeComponent();
            InitializeListView(); // Ensure the ListView is initialized
        }

        private void InitializeListView()
        {
            // Ensure the ListView control exists
            if (lstAppointmentDetails != null)
            {
                lstAppointmentDetails.View = View.Details;
                lstAppointmentDetails.FullRowSelect = true;
                lstAppointmentDetails.Columns.Add("First Name");
                lstAppointmentDetails.Columns.Add("Last Name");
                lstAppointmentDetails.Columns.Add("Appointment Date Start");
                lstAppointmentDetails.Columns.Add("Appointment Date End");

            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            // Navigate back to the main menu
            FormMainMenu mainMenu = new FormMainMenu(null); // Pass null or modify constructor to not require an email
            mainMenu.Show(); // Show the main menu
            this.Close(); // Close the current form
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            participantEmail = txtParticipantEmail.Text; // Get the email entered by the lab coordinator or participant

            if (!string.IsNullOrEmpty(participantEmail))
            {
                participantUserID = GetUserIDByEmail(participantEmail);
                if (participantUserID != -1)
                {
                    // Fetch and display the participant's appointment details
                    DisplayAppointmentDetails();
                }
                else
                {
                    MessageBox.Show("Participant with this email not found.", "Error");
                }
            }
            else
            {
                MessageBox.Show("Please enter a participant's email.", "Error");
            }
        }

        // Method to fetch the participant's userID based on email
        private int GetUserIDByEmail(string email)
        {
            int userID = -1; // Default to -1 if user not found

            string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Trust Server Certificate=True";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT userID FROM Users WHERE email = @Email";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Email", email);

                    conn.Open();
                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        userID = Convert.ToInt32(result);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching user ID: {ex.Message}", "Error");
            }

            return userID;
        }

        private void DisplayAppointmentDetails()
        {
            string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Trust Server Certificate=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // SQL Query to fetch data excluding canceled appointments
                    string query = @"
                        SELECT 
                            u.FirstName, 
                            u.LastName, 
                            a.AppointmentDateStart,
                            a.AppointmentDateEnd,
                            a.AppointmentID,
                            a.status
                        FROM 
                            [BTM495 DB].[dbo].[Users] u
                        INNER JOIN 
                            [BTM495 DB].[dbo].[Appointment] a ON u.UserID = a.UserID
                        WHERE 
                            u.email = @Email AND 
                            (a.status IS NULL OR a.status != 'canceled')
                        ORDER BY
                        a.AppointmentDateStart ASC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Email", participantEmail);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Clear previous results
                            lstAppointmentDetails.Items.Clear();

                            if (reader.HasRows)
                            {
                                // Read results
                                while (reader.Read())
                                {
                                    ListViewItem item = new ListViewItem(reader["FirstName"].ToString());
                                    item.SubItems.Add(reader["LastName"].ToString());
                                    item.SubItems.Add(Convert.ToDateTime(reader["AppointmentDateStart"]).ToString("yyyy-MM-dd HH:mm")); // Format to exclude seconds
                                    item.SubItems.Add(Convert.ToDateTime(reader["AppointmentDateEnd"]).ToString("yyyy-MM-dd HH:mm")); // Format to exclude seconds

                                    // Store the appointment ID in the item's Tag property
                                    item.Tag = Convert.ToInt32(reader["AppointmentID"]);

                                    lstAppointmentDetails.Items.Add(item);
                                }

                                // Adjust column widths to fit content
                                foreach (ColumnHeader column in lstAppointmentDetails.Columns)
                                {
                                    column.Width = -2; // Auto-size the columns
                                }
                            }
                            else
                            {
                                MessageBox.Show("The participant doesn't have any scheduled appointment.", "Information");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Button click event to confirm appointment cancellation
        private void btnConfirmCancelLC_Click(object sender, EventArgs e)
        {
            if (lstAppointmentDetails.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = lstAppointmentDetails.SelectedItems[0];
                appointmentDateStart = DateTime.Parse(selectedItem.SubItems[2].Text);
                int appointmentID = (int)selectedItem.Tag; // Use the stored Appointment ID

                    try
                    {
                        // Call the method to cancel the appointment
                        UpdateAppointment(appointmentID);

                        // Show a success message
                        MessageBox.Show("The appointment has been canceled.", "Success");

                    }
                    catch (Exception ex)
                    {
                        // Handle any errors that occur during the cancellation process
                        MessageBox.Show($"Error during cancellation: {ex.Message}", "Error");
                    }
                }
            
            else
            {
                // If no appointment is selected, show an error message
                MessageBox.Show("Please select an appointment to cancel.", "Error");
            }
        }

        // Method to cancel the appointment
        private void UpdateAppointment(int appointmentID)
        {
            try
            {
                string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Trust Server Certificate=True";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Appointment SET status = 'canceled', cancellationDate = @CancellationDate " +
                                   "WHERE appointmentID = @AppointmentID";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@CancellationDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@AppointmentID", appointmentID);

                    conn.Open();
                    cmd.ExecuteNonQuery(); // Execute the update query to cancel the appointment
                }
            }
            catch (Exception ex)
            {
                // Handle any errors during database operation
                MessageBox.Show($"Error canceling appointment: {ex.Message}", "Error");
            }
        }

        // Button click event to save the cancellation request for later
        private void btnSaveForLater_Click(object sender, EventArgs e)
        {
            // You can implement a feature to save the cancellation for later, such as storing the request
            // in a database or a separate table to be reviewed by the lab coordinator at a later time.
            MessageBox.Show("The cancellation request has been saved for later.", "Saved");
        }
    }
}
