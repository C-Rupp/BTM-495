﻿using Microsoft.Data.SqlClient;
using System;
using System.Windows.Forms;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormCreateProfile : Form
    {
        public FormCreateProfile()
        {
            InitializeComponent();
        }

        private void btnCreateProfile_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();

            if (EmailExists(email))
            {
                MessageBox.Show("A profile already exists for this email.", "Error");
                return;
            }

            DateTime dateOfBirth = dtpDateOfBirth.Value;
            int age = DateTime.Now.Year - dateOfBirth.Year;

            // Check if the participant is at least 18 years old
            if (dateOfBirth > DateTime.Now.AddYears(-age)) age--;

            if (age < 18)
            {
                MessageBox.Show("You must be at least 18 years old to register.", "Age Restriction", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Trust Server Certificate=True;";

                // Initialize user ID
                int newUserID;

                // Fetch the highest existing userID from the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string getMaxIDQuery = "SELECT ISNULL(MAX(userID), 0) FROM [dbo].[Users]";
                    using (SqlCommand command = new SqlCommand(getMaxIDQuery, connection))
                    {
                        int maxID = Convert.ToInt32(command.ExecuteScalar());
                        newUserID = maxID + 1; // Increment the max ID to generate the new user ID
                    }
                }

                // Initialize participant ID
                int newParticipantID;

                // Fetch the highest existing participantID from the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string getMaxIDQuery = "SELECT ISNULL(MAX(participantID), 0) FROM [dbo].[Participant]";
                    using (SqlCommand command = new SqlCommand(getMaxIDQuery, connection))
                    {
                        int maxID = Convert.ToInt32(command.ExecuteScalar());
                        newParticipantID = maxID + 1; // Increment the max ID to generate the new participant ID
                    }
                }

                // Insert user and participant into the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    {
                        try
                        {
                            string insertUserQuery = @"
                                INSERT INTO [dbo].[Users] 
                                (userID, firstName, lastName, role, email, password) 
                                VALUES 
                                (@UserID, @FirstName, @LastName, @Role, @Email, @Password)";

                            string insertParticipantQuery = @"
                                INSERT INTO [dbo].[Participant]
                                (participantID, userID, gender, dateOfBirth, height, weight, emergencyContactName, emergencyContactPhone, eligibilityStatus) 
                                VALUES
                                (@ParticipantID, @UserID, @Gender, @DateOfBirth, @Height, @Weight, @EmergencyContactName, @EmergencyContactPhone, @EligibilityStatus);";

                            using (SqlCommand insertUserCommand = new SqlCommand(insertUserQuery, connection))
                            {
                                insertUserCommand.Parameters.AddWithValue("@UserID", newUserID);
                                insertUserCommand.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                                insertUserCommand.Parameters.AddWithValue("@LastName", txtLastName.Text);
                                insertUserCommand.Parameters.AddWithValue("@Role", "Participant");
                                insertUserCommand.Parameters.AddWithValue("@Email", email);

                                // Check if the passwords are empty
                                if (string.IsNullOrEmpty(txtPassword.Text))
                                {
                                    MessageBox.Show("A password needs to be created.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return; // Exit the method if passwords are empty
                                }

                                // Check if the passwords match
                                if (txtPassword.Text == txtConfirmPassword.Text)
                                {
                                    insertUserCommand.Parameters.AddWithValue("@Password", txtPassword.Text);
                                }
                                else
                                {
                                    MessageBox.Show("Passwords are not matching", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return; // Exit the method if passwords do not match
                                }

                                insertUserCommand.ExecuteNonQuery();
                            }

                            using (SqlCommand insertParticipantCommand = new SqlCommand(insertParticipantQuery, connection))
                            {
                                insertParticipantCommand.Parameters.AddWithValue("@ParticipantID", newParticipantID);
                                insertParticipantCommand.Parameters.AddWithValue("@UserID", newUserID);
                                insertParticipantCommand.Parameters.AddWithValue("@Gender", txtGender.Text);
                                insertParticipantCommand.Parameters.AddWithValue("@DateOfBirth", dtpDateOfBirth.Value);
                                insertParticipantCommand.Parameters.AddWithValue("@Weight", int.Parse(txtWeight.Text));
                                insertParticipantCommand.Parameters.AddWithValue("@Height", int.Parse(txtHeight.Text));
                                insertParticipantCommand.Parameters.AddWithValue("@EmergencyContactName", txtEmergencyContactName.Text);
                                insertParticipantCommand.Parameters.AddWithValue("@EmergencyContactPhone", txtEmergencyContactPhone.Text);
                                insertParticipantCommand.Parameters.AddWithValue("@EligibilityStatus", DBNull.Value);

                                insertParticipantCommand.ExecuteNonQuery();
                            }
                            MessageBox.Show($"Profile has been created: Use email {email} to log in");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"An error occurred: {ex.Message}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private bool EmailExists(string email)
        {
            string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Trust Server Certificate=True;"; // Update with your SQL Server connection string
            string query = "SELECT COUNT(*) FROM Users WHERE Email = @Email";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", email);

                try
                {
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while checking the email: " + ex.Message, "Error");
                    return false;
                }
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Login login = new Login(); // Pass null or modify constructor to not require an email
            login.Show(); // Show the main menu
            this.Close(); // Close the current form
        }
    }
}
