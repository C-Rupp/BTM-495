using Microsoft.Data.SqlClient;
using System;
using System.Windows.Forms;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormMainMenu : Form
    {
        public string email;

        public FormMainMenu(string email)
        {
            InitializeComponent();
            this.email = email;
            InitializeListView();
            LoadAllParticipants(); // Load all participants by default
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create an instance of the formAddAppointment
            FormAddAppointment formAddAppointment = new FormAddAppointment();

            this.Hide();

            // Show the formAddAppointment
            formAddAppointment.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //created by accident don't delete or it will caused errors
        }

        private void btnDisplayAppt_Click(object sender, EventArgs e)
        {
            FormDisplayAppointment formDisplayAppointment = new FormDisplayAppointment();
            this.Hide();
            formDisplayAppointment.ShowDialog();
        }

        private void btnEligibility_Click(object sender, EventArgs e)
        {
            FormEligibilityVerification formEligibilityVerification = new FormEligibilityVerification();
            this.Hide();
            formEligibilityVerification.ShowDialog();
        }

        private void btnCancelAppt_Click(object sender, EventArgs e)
        {
            FormCancelAppointment formCancelAppointment = new FormCancelAppointment();
            this.Hide();
            formCancelAppointment.ShowDialog();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string firstName = sfirst.Text.Trim();
            string lastName = slast.Text.Trim();

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
            {
                MessageBox.Show("Please enter both first name and last name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SearchParticipants(firstName, lastName);
        }

        private void InitializeListView()
        {
            // Ensure the ListView control exists
            if (lstResults != null)
            {
                lstResults.View = View.Details;
                lstResults.FullRowSelect = true;
                lstResults.Columns.Add("User ID");
                lstResults.Columns.Add("First Name");
                lstResults.Columns.Add("Last Name");
                lstResults.Columns.Add("Email");
                lstResults.Columns.Add("Gender");
                lstResults.Columns.Add("Date of Birth");
                lstResults.Columns.Add("Eligibility Status");
            }
        }

        private void LoadAllParticipants()
        {
            string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Trust Server Certificate=True;";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT u.userID, u.firstName, u.lastName, p.gender, u.email, p.dateOfBirth, p.eligibilitystatus
                        FROM [BTM495 DB].[dbo].[Participant] p
                        JOIN [BTM495 DB].[dbo].[Users] u ON p.userID = u.userID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            lstResults.Items.Clear(); // Clear previous results

                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    ListViewItem item = new ListViewItem(reader["userID"].ToString());
                                    item.SubItems.Add(reader["firstName"].ToString());
                                    item.SubItems.Add(reader["lastName"].ToString());
                                    item.SubItems.Add(reader["email"].ToString());
                                    item.SubItems.Add(reader["gender"].ToString());
                                    item.SubItems.Add(Convert.ToDateTime(reader["dateOfBirth"]).ToString("yyyy-MM-dd")); // Format to exclude time
                                    item.SubItems.Add(reader["eligibilitystatus"].ToString());

                                    lstResults.Items.Add(item);
                                }

                                // Adjust column widths to fit content
                                foreach (ColumnHeader column in lstResults.Columns)
                                {
                                    column.Width = -2; // Auto-size the columns
                                }
                            }
                            else
                            {
                                lstResults.Items.Add("No participants found.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SearchParticipants(string firstName, string lastName)
        {
            string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Trust Server Certificate=True;";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT u.userID, u.firstName, u.lastName, p.gender, u.email, p.dateOfBirth, p.eligibilitystatus
                        FROM [BTM495 DB].[dbo].[Participant] p
                        JOIN [BTM495 DB].[dbo].[Users] u ON p.userID = u.userID
                        WHERE u.firstName = @FirstName AND u.lastName = @LastName";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@FirstName", firstName);
                        command.Parameters.AddWithValue("@LastName", lastName);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            lstResults.Items.Clear(); // Clear previous results

                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    ListViewItem item = new ListViewItem(reader["userID"].ToString());
                                    item.SubItems.Add(reader["firstName"].ToString());
                                    item.SubItems.Add(reader["lastName"].ToString());
                                    item.SubItems.Add(reader["email"].ToString());
                                    item.SubItems.Add(reader["gender"].ToString());
                                    item.SubItems.Add(Convert.ToDateTime(reader["dateOfBirth"]).ToString("yyyy-MM-dd")); // Format to exclude time
                                    item.SubItems.Add(reader["eligibilitystatus"].ToString());

                                    lstResults.Items.Add(item);
                                }

                                // Adjust column widths to fit content
                                foreach (ColumnHeader column in lstResults.Columns)
                                {
                                    column.Width = -2; // Auto-size the columns
                                }
                            }
                            else
                            {
                                MessageBox.Show("No participants found with the provided first and last name.", "Information");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
