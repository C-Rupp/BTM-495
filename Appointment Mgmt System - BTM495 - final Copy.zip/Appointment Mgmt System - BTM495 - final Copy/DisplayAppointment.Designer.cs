﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class FormDisplayAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pbMenuBar = new PictureBox();
            btnHome = new Button();
            lstAppointments = new ListView();
            cmbBoxMonth = new ComboBox();
            lblYear = new Label();
            txtBoxYear = new TextBox();
            lbMonth = new Label();
            btnDisplayAppointment = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(237, 27, 47);
            label1.Font = new Font("Garamond", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(28, 9);
            label1.Name = "label1";
            label1.Size = new Size(93, 30);
            label1.TabIndex = 16;
            label1.Text = "McGill";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(237, 27, 47);
            pictureBox2.Location = new Point(-1, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(153, 49);
            pictureBox2.TabIndex = 15;
            pictureBox2.TabStop = false;
            // 
            // pbMenuBar
            // 
            pbMenuBar.BackColor = Color.Black;
            pbMenuBar.Location = new Point(-1, 0);
            pbMenuBar.Name = "pbMenuBar";
            pbMenuBar.Size = new Size(1412, 49);
            pbMenuBar.TabIndex = 14;
            pbMenuBar.TabStop = false;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(237, 27, 47);
            btnHome.FlatStyle = FlatStyle.Popup;
            btnHome.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHome.ForeColor = SystemColors.Control;
            btnHome.Location = new Point(1320, 0);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(91, 49);
            btnHome.TabIndex = 51;
            btnHome.Text = "Home";
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // lstAppointments
            // 
            lstAppointments.Location = new Point(127, 195);
            lstAppointments.Name = "lstAppointments";
            lstAppointments.Size = new Size(1157, 364);
            lstAppointments.TabIndex = 64;
            lstAppointments.UseCompatibleStateImageBehavior = false;
            lstAppointments.View = View.Details;
            // 
            // cmbBoxMonth
            // 
            cmbBoxMonth.FormattingEnabled = true;
            cmbBoxMonth.Location = new Point(127, 135);
            cmbBoxMonth.Name = "cmbBoxMonth";
            cmbBoxMonth.Size = new Size(215, 23);
            cmbBoxMonth.TabIndex = 63;
            // 
            // lblYear
            // 
            lblYear.AutoSize = true;
            lblYear.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblYear.ForeColor = Color.Black;
            lblYear.Location = new Point(431, 89);
            lblYear.Name = "lblYear";
            lblYear.Size = new Size(43, 21);
            lblYear.TabIndex = 61;
            lblYear.Text = "Year";
            // 
            // txtBoxYear
            // 
            txtBoxYear.Location = new Point(431, 135);
            txtBoxYear.Name = "txtBoxYear";
            txtBoxYear.Size = new Size(226, 23);
            txtBoxYear.TabIndex = 60;
            // 
            // lbMonth
            // 
            lbMonth.AutoSize = true;
            lbMonth.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbMonth.ForeColor = Color.Black;
            lbMonth.Location = new Point(127, 89);
            lbMonth.Name = "lbMonth";
            lbMonth.Size = new Size(61, 21);
            lbMonth.TabIndex = 62;
            lbMonth.Text = "Month";
            // 
            // btnDisplayAppointment
            // 
            btnDisplayAppointment.BackColor = Color.FromArgb(237, 27, 47);
            btnDisplayAppointment.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDisplayAppointment.ForeColor = SystemColors.Control;
            btnDisplayAppointment.Location = new Point(541, 589);
            btnDisplayAppointment.Name = "btnDisplayAppointment";
            btnDisplayAppointment.Size = new Size(344, 42);
            btnDisplayAppointment.TabIndex = 59;
            btnDisplayAppointment.Text = "Display Appointments";
            btnDisplayAppointment.UseVisualStyleBackColor = false;
            btnDisplayAppointment.Click += btnDisplayAppointment_Click;
            // 
            // FormDisplayAppointment
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1410, 721);
            Controls.Add(lstAppointments);
            Controls.Add(cmbBoxMonth);
            Controls.Add(lblYear);
            Controls.Add(txtBoxYear);
            Controls.Add(lbMonth);
            Controls.Add(btnDisplayAppointment);
            Controls.Add(btnHome);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pbMenuBar);
            Name = "FormDisplayAppointment";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Display Appointment";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        public Label label1;
        private PictureBox pictureBox2;
        private PictureBox pbMenuBar;
        private Button btnHome;
        private ListView lstAppointments;
        private ComboBox cmbBoxMonth;
        public Label lblYear;
        public TextBox txtBoxYear;
        public Label lbMonth;
        private Button btnDisplayAppointment;
    }
}