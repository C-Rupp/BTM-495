﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class FormEligibilityVerification
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pbMenuBar = new PictureBox();
            lblUserId = new Label();
            txtUserId = new TextBox();
            lblEligibilityStatus = new Label();
            cmbEligibilityStatus = new ComboBox();
            btnUpdate = new Button();
            btnHome = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(237, 27, 47);
            label1.Font = new Font("Garamond", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(28, 9);
            label1.Name = "label1";
            label1.Size = new Size(93, 30);
            label1.TabIndex = 16;
            label1.Text = "McGill";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(237, 27, 47);
            pictureBox2.Location = new Point(-1, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(153, 49);
            pictureBox2.TabIndex = 15;
            pictureBox2.TabStop = false;
            // 
            // pbMenuBar
            // 
            pbMenuBar.BackColor = Color.Black;
            pbMenuBar.Location = new Point(-1, 0);
            pbMenuBar.Name = "pbMenuBar";
            pbMenuBar.Size = new Size(1412, 49);
            pbMenuBar.TabIndex = 14;
            pbMenuBar.TabStop = false;
            // 
            // lblUserId
            // 
            lblUserId.AutoSize = true;
            lblUserId.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUserId.ForeColor = Color.Black;
            lblUserId.Location = new Point(358, 119);
            lblUserId.Name = "lblUserId";
            lblUserId.Size = new Size(65, 21);
            lblUserId.TabIndex = 18;
            lblUserId.Text = "User ID";
            // 
            // txtUserId
            // 
            txtUserId.Location = new Point(358, 165);
            txtUserId.Name = "txtUserId";
            txtUserId.Size = new Size(226, 23);
            txtUserId.TabIndex = 17;
            // 
            // lblEligibilityStatus
            // 
            lblEligibilityStatus.AutoSize = true;
            lblEligibilityStatus.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEligibilityStatus.ForeColor = Color.Black;
            lblEligibilityStatus.Location = new Point(805, 119);
            lblEligibilityStatus.Name = "lblEligibilityStatus";
            lblEligibilityStatus.Size = new Size(139, 21);
            lblEligibilityStatus.TabIndex = 19;
            lblEligibilityStatus.Text = "Eligibility Status:";
            // 
            // cmbEligibilityStatus
            // 
            cmbEligibilityStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEligibilityStatus.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmbEligibilityStatus.ForeColor = Color.Black;
            cmbEligibilityStatus.FormattingEnabled = true;
            cmbEligibilityStatus.Items.AddRange(new object[] { "Eligible", "Ineligible" });
            cmbEligibilityStatus.Location = new Point(805, 159);
            cmbEligibilityStatus.Name = "cmbEligibilityStatus";
            cmbEligibilityStatus.Size = new Size(226, 29);
            cmbEligibilityStatus.TabIndex = 20;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(237, 27, 47);
            btnUpdate.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUpdate.ForeColor = SystemColors.Control;
            btnUpdate.Location = new Point(539, 584);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(344, 42);
            btnUpdate.TabIndex = 46;
            btnUpdate.Text = "Update Eligibility";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click_1;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(237, 27, 47);
            btnHome.FlatStyle = FlatStyle.Popup;
            btnHome.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHome.ForeColor = SystemColors.Control;
            btnHome.Location = new Point(1320, 0);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(91, 49);
            btnHome.TabIndex = 48;
            btnHome.Text = "Home";
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click_1;
            // 
            // FormEligibilityVerification
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1410, 721);
            Controls.Add(btnHome);
            Controls.Add(btnUpdate);
            Controls.Add(lblUserId);
            Controls.Add(txtUserId);
            Controls.Add(lblEligibilityStatus);
            Controls.Add(cmbEligibilityStatus);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pbMenuBar);
            Name = "FormEligibilityVerification";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Eligibility Verification";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        public Label label1;
        private PictureBox pictureBox2;
        private PictureBox pbMenuBar;
        public Label lblUserId;
        public TextBox txtUserId;
        public Label lblEligibilityStatus;
        public ComboBox cmbEligibilityStatus;
        private Button btnUpdate;
        private Button btnHome;
    }
}