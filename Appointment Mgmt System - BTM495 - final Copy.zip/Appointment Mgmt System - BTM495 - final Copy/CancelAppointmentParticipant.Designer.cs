﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class CancelAppointmentParticipant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox3 = new PictureBox();
            lblDetail = new Label();
            btnConfirmCancel = new Button();
            btnEnter = new Button();
            txtParticipantEmail = new TextBox();
            lblEmail = new Label();
            lstAppointmentDetails = new ListView();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(237, 27, 47);
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.Control;
            button1.Location = new Point(1321, 0);
            button1.Name = "button1";
            button1.Size = new Size(91, 49);
            button1.TabIndex = 59;
            button1.Text = "Home";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(237, 27, 47);
            label2.Font = new Font("Garamond", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(29, 9);
            label2.Name = "label2";
            label2.Size = new Size(93, 30);
            label2.TabIndex = 58;
            label2.Text = "McGill";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(237, 27, 47);
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(153, 49);
            pictureBox1.TabIndex = 57;
            pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Black;
            pictureBox3.Location = new Point(0, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(1412, 49);
            pictureBox3.TabIndex = 56;
            pictureBox3.TabStop = false;
            // 
            // lblDetail
            // 
            lblDetail.AutoSize = true;
            lblDetail.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDetail.ForeColor = Color.Black;
            lblDetail.Location = new Point(437, 257);
            lblDetail.Name = "lblDetail";
            lblDetail.Size = new Size(169, 21);
            lblDetail.TabIndex = 65;
            lblDetail.Text = "Appointment Details";
            // 
            // btnConfirmCancel
            // 
            btnConfirmCancel.BackColor = Color.FromArgb(237, 27, 47);
            btnConfirmCancel.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnConfirmCancel.ForeColor = SystemColors.Control;
            btnConfirmCancel.Location = new Point(542, 577);
            btnConfirmCancel.Name = "btnConfirmCancel";
            btnConfirmCancel.Size = new Size(344, 42);
            btnConfirmCancel.TabIndex = 62;
            btnConfirmCancel.Text = "Confirm Appointment Cancellation";
            btnConfirmCancel.UseVisualStyleBackColor = false;
            btnConfirmCancel.Click += btnConfirmCancel_Click;
            // 
            // btnEnter
            // 
            btnEnter.BackColor = Color.FromArgb(237, 27, 47);
            btnEnter.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEnter.ForeColor = SystemColors.Control;
            btnEnter.Location = new Point(840, 171);
            btnEnter.Margin = new Padding(5);
            btnEnter.Name = "btnEnter";
            btnEnter.Size = new Size(163, 34);
            btnEnter.TabIndex = 69;
            btnEnter.Text = "Enter";
            btnEnter.UseVisualStyleBackColor = false;
            btnEnter.Click += btnEnter_Click;
            // 
            // txtParticipantEmail
            // 
            txtParticipantEmail.Font = new Font("Segoe UI", 10F);
            txtParticipantEmail.Location = new Point(437, 177);
            txtParticipantEmail.Margin = new Padding(5);
            txtParticipantEmail.Name = "txtParticipantEmail";
            txtParticipantEmail.Size = new Size(383, 25);
            txtParticipantEmail.TabIndex = 68;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEmail.ForeColor = Color.Black;
            lblEmail.Location = new Point(437, 120);
            lblEmail.Margin = new Padding(5, 0, 5, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(141, 21);
            lblEmail.TabIndex = 67;
            lblEmail.Text = "Participant Email";
            // 
            // lstAppointmentDetails
            // 
            lstAppointmentDetails.Location = new Point(437, 308);
            lstAppointmentDetails.Name = "lstAppointmentDetails";
            lstAppointmentDetails.Size = new Size(566, 196);
            lstAppointmentDetails.TabIndex = 70;
            lstAppointmentDetails.UseCompatibleStateImageBehavior = false;
            lstAppointmentDetails.View = View.Details;
            // 
            // CancelAppointmentParticipant
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1410, 721);
            Controls.Add(lstAppointmentDetails);
            Controls.Add(btnEnter);
            Controls.Add(txtParticipantEmail);
            Controls.Add(lblEmail);
            Controls.Add(lblDetail);
            Controls.Add(btnConfirmCancel);
            Controls.Add(button1);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox3);
            Name = "CancelAppointmentParticipant";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CancelAppointmentParticipant";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        public Label label2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        public Label lblDetail;
        private Button btnConfirmCancel;
        private Button btnEnter;
        private TextBox txtParticipantEmail;
        public Label lblEmail;
        private ListView lstAppointmentDetails;
    }
}