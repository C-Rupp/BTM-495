﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class FormMainMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            btnAddAppointment = new Button();
            btnEligibility = new Button();
            btnDisplayAppt = new Button();
            btnCancelAppt = new Button();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pbMenuBar = new PictureBox();
            btnSearch = new Button();
            slast = new TextBox();
            sfirst = new TextBox();
            lblFirstName = new Label();
            lblLastName = new Label();
            btnLogout = new Button();
            lstResults = new ListView();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).BeginInit();
            SuspendLayout();
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // btnAddAppointment
            // 
            btnAddAppointment.BackColor = Color.FromArgb(237, 27, 47);
            btnAddAppointment.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddAppointment.ForeColor = SystemColors.Control;
            btnAddAppointment.Location = new Point(84, 294);
            btnAddAppointment.Name = "btnAddAppointment";
            btnAddAppointment.Size = new Size(266, 56);
            btnAddAppointment.TabIndex = 0;
            btnAddAppointment.Text = "Add Appointment";
            btnAddAppointment.UseVisualStyleBackColor = false;
            btnAddAppointment.Click += button1_Click;
            // 
            // btnEligibility
            // 
            btnEligibility.BackColor = Color.FromArgb(237, 27, 47);
            btnEligibility.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEligibility.ForeColor = SystemColors.Control;
            btnEligibility.Location = new Point(84, 155);
            btnEligibility.Name = "btnEligibility";
            btnEligibility.Size = new Size(266, 55);
            btnEligibility.TabIndex = 2;
            btnEligibility.Text = "Update Participant Eligibility";
            btnEligibility.UseVisualStyleBackColor = false;
            btnEligibility.Click += btnEligibility_Click;
            // 
            // btnDisplayAppt
            // 
            btnDisplayAppt.BackColor = Color.FromArgb(237, 27, 47);
            btnDisplayAppt.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDisplayAppt.ForeColor = SystemColors.Control;
            btnDisplayAppt.Location = new Point(84, 433);
            btnDisplayAppt.Name = "btnDisplayAppt";
            btnDisplayAppt.Size = new Size(266, 55);
            btnDisplayAppt.TabIndex = 3;
            btnDisplayAppt.Text = "Display Appointments";
            btnDisplayAppt.UseVisualStyleBackColor = false;
            btnDisplayAppt.Click += btnDisplayAppt_Click;
            // 
            // btnCancelAppt
            // 
            btnCancelAppt.BackColor = Color.FromArgb(237, 27, 47);
            btnCancelAppt.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCancelAppt.ForeColor = SystemColors.Control;
            btnCancelAppt.Location = new Point(84, 563);
            btnCancelAppt.Name = "btnCancelAppt";
            btnCancelAppt.Size = new Size(266, 55);
            btnCancelAppt.TabIndex = 4;
            btnCancelAppt.Text = "Cancel Appointment";
            btnCancelAppt.UseVisualStyleBackColor = false;
            btnCancelAppt.Click += btnCancelAppt_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(237, 27, 47);
            label1.Font = new Font("Garamond", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(28, 9);
            label1.Name = "label1";
            label1.Size = new Size(93, 30);
            label1.TabIndex = 16;
            label1.Text = "McGill";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(237, 27, 47);
            pictureBox2.Location = new Point(-1, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(153, 49);
            pictureBox2.TabIndex = 15;
            pictureBox2.TabStop = false;
            // 
            // pbMenuBar
            // 
            pbMenuBar.BackColor = Color.Black;
            pbMenuBar.Location = new Point(-1, 0);
            pbMenuBar.Name = "pbMenuBar";
            pbMenuBar.Size = new Size(1412, 49);
            pbMenuBar.TabIndex = 14;
            pbMenuBar.TabStop = false;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.FromArgb(237, 27, 47);
            btnSearch.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearch.ForeColor = SystemColors.Control;
            btnSearch.Location = new Point(1162, 146);
            btnSearch.Margin = new Padding(3, 2, 3, 2);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(148, 38);
            btnSearch.TabIndex = 21;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // slast
            // 
            slast.Location = new Point(731, 155);
            slast.Margin = new Padding(3, 2, 3, 2);
            slast.Name = "slast";
            slast.Size = new Size(242, 23);
            slast.TabIndex = 18;
            // 
            // sfirst
            // 
            sfirst.Location = new Point(442, 153);
            sfirst.Margin = new Padding(3, 2, 3, 2);
            sfirst.Name = "sfirst";
            sfirst.Size = new Size(239, 23);
            sfirst.TabIndex = 17;
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFirstName.ForeColor = Color.Black;
            lblFirstName.Location = new Point(442, 118);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(92, 21);
            lblFirstName.TabIndex = 22;
            lblFirstName.Text = "First Name";
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLastName.ForeColor = Color.Black;
            lblLastName.Location = new Point(731, 118);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(90, 21);
            lblLastName.TabIndex = 23;
            lblLastName.Text = "Last Name";
            // 
            // btnLogout
            // 
            btnLogout.BackColor = Color.FromArgb(237, 27, 47);
            btnLogout.FlatStyle = FlatStyle.Popup;
            btnLogout.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogout.ForeColor = SystemColors.Control;
            btnLogout.Location = new Point(1320, 0);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(91, 49);
            btnLogout.TabIndex = 72;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += btnLogout_Click;
            // 
            // lstResults
            // 
            lstResults.Location = new Point(438, 209);
            lstResults.Name = "lstResults";
            lstResults.Size = new Size(872, 409);
            lstResults.TabIndex = 73;
            lstResults.UseCompatibleStateImageBehavior = false;
            lstResults.View = View.Details;
            // 
            // FormMainMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1410, 721);
            Controls.Add(lstResults);
            Controls.Add(btnLogout);
            Controls.Add(lblLastName);
            Controls.Add(lblFirstName);
            Controls.Add(btnSearch);
            Controls.Add(slast);
            Controls.Add(sfirst);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pbMenuBar);
            Controls.Add(btnCancelAppt);
            Controls.Add(btnDisplayAppt);
            Controls.Add(btnEligibility);
            Controls.Add(btnAddAppointment);
            Name = "FormMainMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Main Menu";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private Button btnAddAppointment;
        private Button btnEligibility;
        private Button btnDisplayAppt;
        private Button btnCancelAppt;
        public Label label1;
        private PictureBox pictureBox2;
        private PictureBox pbMenuBar;
        private Button btnSearch;
        private TextBox slast;
        private TextBox sfirst;
        public Label lblFirstName;
        public Label lblLastName;
        private Button btnLogout;
        private ListView lstResults;
    }
}
