﻿using Microsoft.Data.SqlClient;
using System;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormAddAppointment : Form
    {
        public FormAddAppointment()
        {
            InitializeComponent();
            // dtpAppointmentStart
            dtpAppointmentStart.CustomFormat = "dd/MM/yyyy HH:mm";
            dtpAppointmentStart.Format = DateTimePickerFormat.Custom;
            // dtpAppointmentEnd
            dtpAppointmentEnd.CustomFormat = "dd/MM/yyyy HH:mm";
            dtpAppointmentEnd.Format = DateTimePickerFormat.Custom;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int userID = int.Parse(txtUserID.Text);

            if (!IsUserEligible(userID))
            {
                MessageBox.Show("The participant is not eligible to add an appointment.", "Eligibility Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtpAppointmentEnd.Value <= dtpAppointmentStart.Value)
            {
                MessageBox.Show("Appointment end date and time must be greater than the start date and time.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string connectionString = "Data Source = J_inspiration_1\\SQLEXPRESS; Initial Catalog =\"BTM495 DB\";Integrated Security=True;Trust Server Certificate=True";

                // Initialize appointment ID
                int newAppointmentID;

                // Fetch the highest existing appointmentID from the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string getMaxIDQuery = "SELECT ISNULL(MAX(appointmentID), 0) FROM [dbo].[Appointment]";
                    using (SqlCommand command = new SqlCommand(getMaxIDQuery, connection))
                    {
                        int maxID = Convert.ToInt32(command.ExecuteScalar());
                        newAppointmentID = maxID + 1; // Increment the max ID to generate the new appointment ID
                    }
                }

                // Insert appointment into the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string insertQuery = @"
                        INSERT INTO [dbo].[Appointment] 
                        (appointmentID, userid, appointmentDateStart, appointmentDateEnd, room, detail, status, cancellationDate) 
                        VALUES 
                        (@AppointmentID, @UserId, @AppointmentDateStart, @AppointmentDateEnd, @Room, @Detail, @Status, @CancellationDate)";

                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@AppointmentID", newAppointmentID);
                        command.Parameters.AddWithValue("@UserId", userID);
                        command.Parameters.AddWithValue("@AppointmentDateStart", dtpAppointmentStart.Value);
                        command.Parameters.AddWithValue("@AppointmentDateEnd", dtpAppointmentEnd.Value);
                        command.Parameters.AddWithValue("@Room", txtRoom.Text);
                        command.Parameters.AddWithValue("@Detail", txtDetail.Text);
                        command.Parameters.AddWithValue("@Status", "active");
                        command.Parameters.AddWithValue("@CancellationDate", DBNull.Value);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"Appointment added successfully with Appointment ID: {newAppointmentID}");
                        }
                        else
                        {
                            MessageBox.Show("Failed to add appointment to the database.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private bool IsUserEligible(int userID)
        {
            string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Trust Server Certificate=True";
            string query = "SELECT eligibilityStatus FROM Participant WHERE userID = @UserID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserID", userID);

                try
                {
                    connection.Open();
                    var eligibilitystatus = command.ExecuteScalar() as string;
                    return eligibilitystatus == "Eligible";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while checking eligibility status: " + ex.Message, "Error");
                    return false;
                }
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            // Navigate back to the main menu
            FormMainMenu mainMenu = new FormMainMenu(null); // Pass null or modify constructor to not require an email
            mainMenu.Show(); // Show the main menu
            this.Close(); // Close the current form
        }
    }
}
