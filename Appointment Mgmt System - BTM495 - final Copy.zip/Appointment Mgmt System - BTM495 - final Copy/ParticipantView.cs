﻿namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormParticipantView : Form
    {

        private string email;

        public FormParticipantView(string email)
        {
            InitializeComponent();
            this.email = email;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //created by accident don't delete or it will caused errors
        }

        private void btnCancelAppt_Click(object sender, EventArgs e)
        {

            CancelAppointmentParticipant formCancelAppointmentParticipant = new CancelAppointmentParticipant();
            this.Hide();
            formCancelAppointmentParticipant.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
