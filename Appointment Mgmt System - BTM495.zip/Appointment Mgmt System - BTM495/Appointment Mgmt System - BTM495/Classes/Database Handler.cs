﻿namespace Appointment_Mgmt_System___BTM495
{

    internal class Database_Handler
    {

    }


}
