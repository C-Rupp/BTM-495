namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormMainMenu : Form
    {

        public string email;

        public FormMainMenu(string email)
        {

            InitializeComponent();
            this.email = email;
        }

        private void button1_Click(object sender, EventArgs e)
        {


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

}


