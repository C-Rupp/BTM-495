﻿using Microsoft.Data.SqlClient;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPassword.Text;

            if (ValidateUser(email, password))
            {
                MessageBox.Show("Login successful!", "Success");
                // Proceed to the next form or action
                FormMainMenu formMainMenu = new FormMainMenu(email);
                formMainMenu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid email or password.", "Error");
            }
        }

        private bool ValidateUser(string email, string password)
        {
            string connectionString = "Data Source=DESKTOP-MN\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Encrypt=True;Trust Server Certificate=True"; // Update with your SQL Server connection string
            string query = "SELECT COUNT(1) FROM Users WHERE Email = @email AND password = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@Password", password);

                try
                {
                    connection.Open();
                    int count = Convert.ToInt32(command.ExecuteScalar());
                    return count == 1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error");
                    return false;
                }
            }
        }

        private void lblUsername_Click(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}




