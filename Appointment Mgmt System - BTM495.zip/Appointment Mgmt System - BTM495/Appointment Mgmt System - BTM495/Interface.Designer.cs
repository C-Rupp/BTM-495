﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class FormMainMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            btnAddAppointment = new Button();
            btnEligibility = new Button();
            btnDisplayAppt = new Button();
            SuspendLayout();
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // btnAddAppointment
            // 
            btnAddAppointment.BackColor = Color.FromArgb(188, 186, 223);
            btnAddAppointment.Location = new Point(1234, 35);
            btnAddAppointment.Name = "btnAddAppointment";
            btnAddAppointment.Size = new Size(142, 42);
            btnAddAppointment.TabIndex = 0;
            btnAddAppointment.Text = "Add Appointment";
            btnAddAppointment.UseVisualStyleBackColor = false;
            btnAddAppointment.Click += button1_Click;
            // 
            // btnEligibility
            // 
            btnEligibility.BackColor = Color.FromArgb(188, 186, 223);
            btnEligibility.Location = new Point(1570, 35);
            btnEligibility.Name = "btnEligibility";
            btnEligibility.Size = new Size(142, 42);
            btnEligibility.TabIndex = 2;
            btnEligibility.Text = "Update Eligibility";
            btnEligibility.UseVisualStyleBackColor = false;
            // 
            // btnDisplayAppt
            // 
            btnDisplayAppt.BackColor = Color.FromArgb(188, 186, 223);
            btnDisplayAppt.Location = new Point(1407, 35);
            btnDisplayAppt.Name = "btnDisplayAppt";
            btnDisplayAppt.Size = new Size(142, 42);
            btnDisplayAppt.TabIndex = 3;
            btnDisplayAppt.Text = "Display Appointments";
            btnDisplayAppt.UseVisualStyleBackColor = false;
            // 
            // FormMainMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(42, 30, 60);
            ClientSize = new Size(1767, 911);
            Controls.Add(btnDisplayAppt);
            Controls.Add(btnEligibility);
            Controls.Add(btnAddAppointment);
            Name = "FormMainMenu";
            Text = "Main Menu";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private Button btnAddAppointment;
        private Button btnEligibility;
        private Button btnDisplayAppt;
    }
}
