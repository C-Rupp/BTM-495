﻿namespace Appointment_Mgmt_System___BTM495
{
    public class LabCoordinator : User
    {
    }
}
