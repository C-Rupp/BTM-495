﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Appointment_Mgmt_System___BTM495
{
    using System.Data.Common;
    using System.Data.SqlClient;

    public class Database_Handler
    {
        string connectionString = "Data Source=DESKTOP-MN\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
        
    }
}
