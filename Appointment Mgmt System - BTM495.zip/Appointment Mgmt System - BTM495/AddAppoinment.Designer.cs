﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class AddAppoinment
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnSubmit = new Button();
            txtUserID = new TextBox();
            txtRoom = new TextBox();
            txtDetail = new TextBox();
            txtStatus = new TextBox();
            lblUserID = new Label();
            lblAppointmentStart = new Label();
            lblAppointmentEnd = new Label();
            lblRoom = new Label();
            lblDetail = new Label();
            lblStatus = new Label();
            dtpAppointmentStart = new DateTimePicker();
            dtpAppointmentEnd = new DateTimePicker();
            SuspendLayout();

            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(182, 290);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(94, 29);
            btnSubmit.TabIndex = 8;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;

            // 
            // txtUserID
            // 
            txtUserID.Location = new Point(167, 53);
            txtUserID.Name = "txtUserID";
            txtUserID.Size = new Size(125, 27);
            txtUserID.TabIndex = 1;

            // 
            // txtRoom
            // 
            txtRoom.Location = new Point(167, 150);
            txtRoom.Name = "txtRoom";
            txtRoom.Size = new Size(125, 27);
            txtRoom.TabIndex = 2;

            // 
            // txtDetail
            // 
            txtDetail.Location = new Point(167, 183);
            txtDetail.Name = "txtDetail";
            txtDetail.Size = new Size(125, 27);
            txtDetail.TabIndex = 3;

            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(167, 216);
            txtStatus.Name = "txtStatus";
            txtStatus.Size = new Size(125, 27);
            txtStatus.TabIndex = 4;

            // 
            // lblUserID
            // 
            lblUserID.AutoSize = true;
            lblUserID.Location = new Point(104, 56);
            lblUserID.Name = "lblUserID";
            lblUserID.Size = new Size(57, 20);
            lblUserID.TabIndex = 19;
            lblUserID.Text = "User ID";

            // 
            // lblAppointmentStart
            // 
            lblAppointmentStart.AutoSize = true;
            lblAppointmentStart.Location = new Point(3, 89);
            lblAppointmentStart.Name = "lblAppointmentStart";
            lblAppointmentStart.Size = new Size(168, 20);
            lblAppointmentStart.TabIndex = 11;
            lblAppointmentStart.Text = "Appointment Date Start";

            // 
            // lblAppointmentEnd
            // 
            lblAppointmentEnd.AutoSize = true;
            lblAppointmentEnd.Location = new Point(12, 120);
            lblAppointmentEnd.Name = "lblAppointmentEnd";
            lblAppointmentEnd.Size = new Size(162, 20);
            lblAppointmentEnd.TabIndex = 12;
            lblAppointmentEnd.Text = "Appointment Date End";

            // 
            // lblRoom
            // 
            lblRoom.AutoSize = true;
            lblRoom.Location = new Point(112, 153);
            lblRoom.Name = "lblRoom";
            lblRoom.Size = new Size(49, 20);
            lblRoom.TabIndex = 10;
            lblRoom.Text = "Room";

            // 
            // lblDetail
            // 
            lblDetail.AutoSize = true;
            lblDetail.Location = new Point(112, 186);
            lblDetail.Name = "lblDetail";
            lblDetail.Size = new Size(49, 20);
            lblDetail.TabIndex = 13;
            lblDetail.Text = "Detail";

            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(112, 219);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(49, 20);
            lblStatus.TabIndex = 14;
            lblStatus.Text = "Status";

            // 
            // dtpAppointmentStart
            // 
            this.dtpAppointmentStart.CustomFormat = "dd/MM/yyyy HH:mm";
            this.dtpAppointmentStart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpAppointmentStart.Location = new System.Drawing.Point(167, 86);
            this.dtpAppointmentStart.Name = "dtpAppointmentStart";
            this.dtpAppointmentStart.ShowUpDown = true;
            this.dtpAppointmentStart.Size = new System.Drawing.Size(250, 27);
            this.dtpAppointmentStart.TabIndex = 17;

            // 
            // dtpAppointmentEnd
            // 
            this.dtpAppointmentEnd.CustomFormat = "dd/MM/yyyy HH:mm";
            this.dtpAppointmentEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpAppointmentEnd.Location = new System.Drawing.Point(167, 117);
            this.dtpAppointmentEnd.Name = "dtpAppointmentEnd";
            this.dtpAppointmentEnd.ShowUpDown = true;
            this.dtpAppointmentEnd.Size = new System.Drawing.Size(250, 27);
            this.dtpAppointmentEnd.TabIndex = 18;

            // 
            // AddAppointment
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblUserID);
            Controls.Add(dtpAppointmentEnd);
            Controls.Add(dtpAppointmentStart);
            Controls.Add(lblStatus);
            Controls.Add(lblDetail);
            Controls.Add(lblAppointmentEnd);
            Controls.Add(lblAppointmentStart);
            Controls.Add(lblRoom);
            Controls.Add(btnSubmit);
            Controls.Add(txtStatus);
            Controls.Add(txtDetail);
            Controls.Add(txtRoom);
            Controls.Add(txtUserID);
            Name = "AddAppointment";
            Text = "Appointment Form";
            Load += AddAppoinment_Load; 
            ResumeLayout(false);
            PerformLayout();
        }

        private TextBox txtUserID;
        private TextBox txtRoom;
        private TextBox txtDetail;
        private TextBox txtStatus;
        private Button btnSubmit;
        private Label lblUserID;
        private Label lblAppointmentStart;
        private Label lblAppointmentEnd;
        private Label lblRoom;
        private Label lblDetail;
        private Label lblStatus;
        private DateTimePicker dtpAppointmentStart;
        private DateTimePicker dtpAppointmentEnd;
    }
}