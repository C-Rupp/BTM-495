﻿using Microsoft.Data.SqlClient;
using System;
using System.Windows.Forms;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class AddAppoinment : Form
    {

        public AddAppoinment()
        {
            InitializeComponent();
        }

        private void EnsureIdentityColumn()
{
            string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM 495 DB\";Integrated Security=True;Trust Server Certificate=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Drop the existing appointmentID column if it's not an identity column
                string dropColumnQuery = @"
            IF EXISTS (SELECT * FROM sys.columns 
                       WHERE Name = N'appointmentID' 
                       AND Object_ID = Object_ID(N'[dbo].[Appointment]') 
                       AND is_identity = 0)
            BEGIN
                ALTER TABLE [dbo].[Appointment] DROP COLUMN appointmentID;
            END";

                using (SqlCommand dropCommand = new SqlCommand(dropColumnQuery, connection))
                {
                    dropCommand.ExecuteNonQuery();
                }

                // Add the appointmentID column as an IDENTITY if it does not already exist or is not an IDENTITY
                string addColumnQuery = @"
            IF NOT EXISTS (SELECT * FROM sys.columns 
                          WHERE Name = N'appointmentID' 
                          AND Object_ID = Object_ID(N'[dbo].[Appointment]'))
            BEGIN
                ALTER TABLE [dbo].[Appointment] 
                ADD appointmentID INT IDENTITY(1,1) NOT NULL PRIMARY KEY;
            END";

                using (SqlCommand addCommand = new SqlCommand(addColumnQuery, connection))
                {
                    addCommand.ExecuteNonQuery();
                }
            }
           
    
    using (SqlConnection connection = new SqlConnection(connectionString))
    {
        connection.Open();

        // Drop the existing appointmentID column if it's not an identity column
        string dropColumnQuery = @"
            IF EXISTS (SELECT * FROM sys.columns 
                       WHERE Name = N'appointmentID' 
                       AND Object_ID = Object_ID(N'[dbo].[Appointment]') 
                       AND is_identity = 0)
            BEGIN
                ALTER TABLE [dbo].[Appointment] DROP COLUMN appointmentID;
            END";

        using (SqlCommand dropCommand = new SqlCommand(dropColumnQuery, connection))
        {
            dropCommand.ExecuteNonQuery();
        }

        // Add the appointmentID column as an IDENTITY if it does not already exist or is not an IDENTITY
        string addColumnQuery = @"
            IF NOT EXISTS (SELECT * FROM sys.columns 
                          WHERE Name = N'appointmentID' 
                          AND Object_ID = Object_ID(N'[dbo].[Appointment]'))
            BEGIN
                ALTER TABLE [dbo].[Appointment] 
                ADD appointmentID INT IDENTITY(1,1) NOT NULL PRIMARY KEY;
            END";

        using (SqlCommand addCommand = new SqlCommand(addColumnQuery, connection))
        {
            addCommand.ExecuteNonQuery();
        }
    }
}

        private void AddAppoinment_Load(object sender, EventArgs e)
        {
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM 495 DB\";Integrated Security=True;Trust Server Certificate=True";

                // Create an instance of the Appointment class (without AppointmentID)
                Appointment newAppointment = new Appointment
                {
                    AppointmentDate = dtpAppointmentStart.Value.ToString("dd/MM/yyyy"),
                    AppointmentTimeStart = dtpAppointmentStart.Value.ToString("HH:mm"),
                    AppointmentTimeEnd = dtpAppointmentEnd.Value.ToString("HH:mm"),
                    Room = txtRoom.Text,
                    Detail = txtDetail.Text,
                    Status = txtStatus.Text,
                    CancellationDate = null // Explicitly set CancellationDate to null
                };

                // Create a dummy user for demonstration (you may want to retrieve user data from elsewhere)
                User user = new User
                {
                    UserId = int.Parse(txtUserID.Text),
                    Role = "Patient",  // Example role, replace it with actual input if necessary
                    FirstName = "John", // Example first name, replace it with actual input if necessary
                    LastName = "Doe",   // Example last name, replace it with actual input if necessary
                    Gender = "Male",    // Example gender, replace it with actual input if necessary
                    DateOfBirth = "01/01/1990", // Example DOB, replace it with actual input if necessary
                    Email = "john.doe@example.com", // Example email, replace it with actual input if necessary
                    Password = "password123"  // Example password, replace it with actual input if necessary
                };

                // Insert appointment data into SQL database and retrieve the generated AppointmentID
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string insertQuery = @"
                INSERT INTO [dbo].[Appointment] 
                (userid, appointmentDateStart, appointmentDateEnd, room, detail, status, cancellationDate) 
                VALUES 
                (@UserId, @AppointmentDateStart, @AppointmentDateEnd, @Room, @Detail, @Status, @CancellationDate);
                SELECT SCOPE_IDENTITY();"; // Fetch the generated AppointmentID

                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        // Set parameters for the SQL query
                        command.Parameters.AddWithValue("@UserId", user.UserId);
                        command.Parameters.AddWithValue("@AppointmentDateStart", dtpAppointmentStart.Value);
                        command.Parameters.AddWithValue("@AppointmentDateEnd", dtpAppointmentEnd.Value);
                        command.Parameters.AddWithValue("@Room", newAppointment.Room);
                        command.Parameters.AddWithValue("@Detail", newAppointment.Detail);
                        command.Parameters.AddWithValue("@Status", newAppointment.Status);
                        command.Parameters.AddWithValue("@CancellationDate", (object)newAppointment.CancellationDate ?? DBNull.Value);

                        // Execute the query and retrieve the generated AppointmentID
                        int generatedAppointmentID = Convert.ToInt32(command.ExecuteScalar());
                        newAppointment.AppointmentID = generatedAppointmentID;
                    }
                }

                // Display the appointment and user details in a message box, including the generated AppointmentID
                string appointmentDetails = $"Appointment Details:\n" +
                                            $"Appointment ID: {newAppointment.AppointmentID}\n" +
                                            $"Date: {newAppointment.AppointmentDate}\n" +
                                            $"Start Time: {newAppointment.AppointmentTimeStart}\n" +
                                            $"End Time: {newAppointment.AppointmentTimeEnd}\n" +
                                            $"Room: {newAppointment.Room}\n" +
                                            $"Detail: {newAppointment.Detail}\n" +
                                            $"Status: {newAppointment.Status}";

                if (!string.IsNullOrEmpty(newAppointment.CancellationDate))
                {
                    appointmentDetails += $"\nCancellation Date: {newAppointment.CancellationDate}";
                }
                else
                {
                    appointmentDetails += "\nCancellation Date: None";
                }

                string userDetails = $"User Details:\n" +
                                     $"User ID: {user.UserId}\n" +
                                     $"Role: {user.Role}\n" +
                                     $"Name: {user.FirstName} {user.LastName}\n" +
                                     $"Gender: {user.Gender}\n" +
                                     $"Date of Birth: {user.DateOfBirth}\n" +
                                     $"Email: {user.Email}";

                MessageBox.Show(appointmentDetails + "\n\n" + userDetails);

            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void lblRoom_Click(object sender, EventArgs e)
        {
        }

        private void dtpAppointmentStart_ValueChanged(object sender, EventArgs e)
        {
            DateTime selectedDateTime1 = dtpAppointmentStart.Value;
            MessageBox.Show($"DateTimePicker1 selected: {selectedDateTime1:MM/dd/yyyy HH:mm}");
        }

        private void dtpAppointmentEnd_ValueChanged(object sender, EventArgs e)
        {
            DateTime selectedDateTime2 = dtpAppointmentEnd.Value;
            MessageBox.Show($"DateTimePicker2 selected: {selectedDateTime2:MM/dd/yyyy HH:mm}");
        }

        private void txtStatus_TextChanged(object sender, EventArgs e)
        {
        }

        private void lblUserID_Click(object sender, EventArgs e)
        {
        }
    }
}
