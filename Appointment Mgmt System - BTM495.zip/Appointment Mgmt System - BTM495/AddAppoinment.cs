﻿using Microsoft.Data.SqlClient;
using System;
using System.Windows.Forms;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class AddAppoinment : Form
    {
        public AddAppoinment()
        {
            InitializeComponent(); // This should call the method defined in the Designer.cs file
        }

        private void AddAppoinment_Load(object sender, EventArgs e)
        {
            // Form load logic (if any)
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=J_inspiration_1\\SQLEXPRESS;Initial Catalog=\"BTM 495 DB\";Integrated Security=True;Trust Server Certificate=True";

                // Initialize appointment ID
                int newAppointmentID;

                // Fetch the highest existing appointmentID from the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string getMaxIDQuery = "SELECT ISNULL(MAX(appointmentID), 0) FROM [dbo].[Appointment]";
                    using (SqlCommand command = new SqlCommand(getMaxIDQuery, connection))
                    {
                        int maxID = Convert.ToInt32(command.ExecuteScalar());
                        newAppointmentID = maxID + 1; // Increment the max ID to generate the new appointment ID
                    }
                }

                // Insert appointment into the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string insertQuery = @"
                        INSERT INTO [dbo].[Appointment] 
                        (appointmentID, userid, appointmentDateStart, appointmentDateEnd, room, detail, status, cancellationDate) 
                        VALUES 
                        (@AppointmentID, @UserId, @AppointmentDateStart, @AppointmentDateEnd, @Room, @Detail, @Status, @CancellationDate)";

                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@AppointmentID", newAppointmentID);
                        command.Parameters.AddWithValue("@UserId", int.Parse(txtUserID.Text));
                        command.Parameters.AddWithValue("@AppointmentDateStart", dtpAppointmentStart.Value);
                        command.Parameters.AddWithValue("@AppointmentDateEnd", dtpAppointmentEnd.Value);
                        command.Parameters.AddWithValue("@Room", txtRoom.Text);
                        command.Parameters.AddWithValue("@Detail", txtDetail.Text);
                        command.Parameters.AddWithValue("@Status", "active");
                        command.Parameters.AddWithValue("@CancellationDate", DBNull.Value);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"Appointment added successfully with Appointment ID: {newAppointmentID}");
                        }
                        else
                        {
                            MessageBox.Show("Failed to add appointment to the database.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
    }
}
