﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class FormMainMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            btnAddAppointment = new Button();
            btnEligibility = new Button();
            btnDisplayAppt = new Button();
            btnCancelAppt = new Button();
            SuspendLayout();
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // btnAddAppointment
            // 
            btnAddAppointment.BackColor = Color.FromArgb(237, 27, 47);
            btnAddAppointment.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddAppointment.ForeColor = SystemColors.Control;
            btnAddAppointment.Location = new Point(42, 55);
            btnAddAppointment.Name = "btnAddAppointment";
            btnAddAppointment.Size = new Size(266, 56);
            btnAddAppointment.TabIndex = 0;
            btnAddAppointment.Text = "Add Appointment";
            btnAddAppointment.UseVisualStyleBackColor = false;
            btnAddAppointment.Click += button1_Click;
            // 
            // btnEligibility
            // 
            btnEligibility.BackColor = Color.FromArgb(237, 27, 47);
            btnEligibility.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEligibility.ForeColor = SystemColors.Control;
            btnEligibility.Location = new Point(933, 56);
            btnEligibility.Name = "btnEligibility";
            btnEligibility.Size = new Size(266, 55);
            btnEligibility.TabIndex = 2;
            btnEligibility.Text = "Update Participant Eligibility";
            btnEligibility.UseVisualStyleBackColor = false;
            // 
            // btnDisplayAppt
            // 
            btnDisplayAppt.BackColor = Color.FromArgb(237, 27, 47);
            btnDisplayAppt.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDisplayAppt.ForeColor = SystemColors.Control;
            btnDisplayAppt.Location = new Point(342, 56);
            btnDisplayAppt.Name = "btnDisplayAppt";
            btnDisplayAppt.Size = new Size(266, 55);
            btnDisplayAppt.TabIndex = 3;
            btnDisplayAppt.Text = "Display Appointments";
            btnDisplayAppt.UseVisualStyleBackColor = false;
            // 
            // btnCancelAppt
            // 
            btnCancelAppt.BackColor = Color.FromArgb(237, 27, 47);
            btnCancelAppt.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCancelAppt.ForeColor = SystemColors.Control;
            btnCancelAppt.Location = new Point(638, 55);
            btnCancelAppt.Name = "btnCancelAppt";
            btnCancelAppt.Size = new Size(266, 55);
            btnCancelAppt.TabIndex = 4;
            btnCancelAppt.Text = "Cancel Appointment";
            btnCancelAppt.UseVisualStyleBackColor = false;
            // 
            // FormMainMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1767, 911);
            Controls.Add(btnCancelAppt);
            Controls.Add(btnDisplayAppt);
            Controls.Add(btnEligibility);
            Controls.Add(btnAddAppointment);
            Name = "FormMainMenu";
            Text = "Main Menu";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private Button btnAddAppointment;
        private Button btnEligibility;
        private Button btnDisplayAppt;
        private Button btnCancelAppt;
    }
}
