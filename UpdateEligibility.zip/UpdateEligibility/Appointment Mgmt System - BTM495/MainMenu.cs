namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormMainMenu : Form
    {

        public string email;

        public FormMainMenu(string email)
        {

            InitializeComponent();
            this.email = email;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddAppoinment form2 = new AddAppoinment(); form2.ShowDialog();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //created by accident don't delete or it will caused errors
        }

        public void btnEligibility_Click(object sender, EventArgs e)
        {
            UpdateEligibilityStatus updateForm = new UpdateEligibilityStatus(this); // Pass reference if needed
            updateForm.Show();
        }
    }

}


