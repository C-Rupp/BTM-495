﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class CancelAppointmentLabCoordinator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private PictureBox pbMenuBar;
        public Label label1;
        private PictureBox pictureBox2;
        public Label lblEmail;
        private TextBox txtParticipantEmail;
        private TextBox txtAppointmentDetailsLC;
        private Button btnSaveForLaterLC;
        private Button btnConfirmCancelLC;
        public Label lblDetailsLC;
        private Button btnEnter;
    }

      
}