namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormMainMenu : Form
    {

        public string email;

        public FormMainMenu(string email)
        {

            InitializeComponent();
            this.email = email;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create an instance of the formAddAppointment
            FormAddAppointment formAddAppointment = new FormAddAppointment();

            this.Hide();

            // Show the formAddAppointment
            formAddAppointment.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //created by accident don't delete or it will caused errors
        }

        private void btnDisplayAppt_Click(object sender, EventArgs e)
        {
            FormDisplayAppointment formDisplayAppointment = new FormDisplayAppointment();
            this.Hide();
            formDisplayAppointment.ShowDialog();
        }

        private void btnEligibility_Click(object sender, EventArgs e)
        {
            FormEligibilityVerification formEligibilityVerification = new FormEligibilityVerification();
            this.Hide();
            formEligibilityVerification.ShowDialog();
        }

        private void btnCancelAppt_Click(object sender, EventArgs e)
        {

        }
    }

}


