﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormAddAppointment : Form
    {
        public FormAddAppointment()
        {
            InitializeComponent();
            // dtpAppointmentStart
            // 
            dtpAppointmentStart.CustomFormat = "dd/MM/yyyy HH:mm";
            dtpAppointmentStart.Format = DateTimePickerFormat.Custom;
            // dtpAppointmentEnd
            // 
            dtpAppointmentEnd.CustomFormat = "dd/MM/yyyy HH:mm";
            dtpAppointmentEnd.Format = DateTimePickerFormat.Custom;

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=DESKTOP-MN\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Encrypt=True;Trust Server Certificate=True";

                // Initialize appointment ID
                int newAppointmentID;

                // Fetch the highest existing appointmentID from the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string getMaxIDQuery = "SELECT ISNULL(MAX(appointmentID), 0) FROM [dbo].[Appointment]";
                    using (SqlCommand command = new SqlCommand(getMaxIDQuery, connection))
                    {
                        int maxID = Convert.ToInt32(command.ExecuteScalar());
                        newAppointmentID = maxID + 1; // Increment the max ID to generate the new appointment ID
                    }
                }

                // Insert appointment into the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string insertQuery = @"
                        INSERT INTO [dbo].[Appointment] 
                        (appointmentID, userid, appointmentDateStart, appointmentDateEnd, room, detail, status, cancellationDate) 
                        VALUES 
                        (@AppointmentID, @UserId, @AppointmentDateStart, @AppointmentDateEnd, @Room, @Detail, @Status, @CancellationDate)";

                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@AppointmentID", newAppointmentID);
                        command.Parameters.AddWithValue("@UserId", int.Parse(txtUserID.Text));
                        command.Parameters.AddWithValue("@AppointmentDateStart", dtpAppointmentStart.Value);
                        command.Parameters.AddWithValue("@AppointmentDateEnd", dtpAppointmentEnd.Value);
                        command.Parameters.AddWithValue("@Room", txtRoom.Text);
                        command.Parameters.AddWithValue("@Detail", txtDetail.Text);
                        command.Parameters.AddWithValue("@Status", "active");
                        command.Parameters.AddWithValue("@CancellationDate", DBNull.Value);


                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"Appointment added successfully with Appointment ID: {newAppointmentID}");
                        }
                        else
                        {
                            MessageBox.Show("Failed to add appointment to the database.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void FormAddAppointment_Load(object sender, EventArgs e)
        {

        }

        private void txtUserID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}