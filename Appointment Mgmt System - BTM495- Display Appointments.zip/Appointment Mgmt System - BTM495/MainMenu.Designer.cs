﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class FormMainMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            btnAddAppointment = new Button();
            btnEligibility = new Button();
            btnDisplayAppt = new Button();
            btnCancelAppt = new Button();
            listBox1 = new ListBox();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pbMenuBar = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).BeginInit();
            SuspendLayout();
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // btnAddAppointment
            // 
            btnAddAppointment.BackColor = Color.FromArgb(237, 27, 47);
            btnAddAppointment.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddAppointment.ForeColor = SystemColors.Control;
            btnAddAppointment.Location = new Point(87, 176);
            btnAddAppointment.Name = "btnAddAppointment";
            btnAddAppointment.Size = new Size(266, 56);
            btnAddAppointment.TabIndex = 0;
            btnAddAppointment.Text = "Add Appointment";
            btnAddAppointment.UseVisualStyleBackColor = false;
            btnAddAppointment.Click += button1_Click;
            // 
            // btnEligibility
            // 
            btnEligibility.BackColor = Color.FromArgb(237, 27, 47);
            btnEligibility.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEligibility.ForeColor = SystemColors.Control;
            btnEligibility.Location = new Point(87, 564);
            btnEligibility.Name = "btnEligibility";
            btnEligibility.Size = new Size(266, 55);
            btnEligibility.TabIndex = 2;
            btnEligibility.Text = "Update Participant Eligibility";
            btnEligibility.UseVisualStyleBackColor = false;
            btnEligibility.Click += btnEligibility_Click;
            // 
            // btnDisplayAppt
            // 
            btnDisplayAppt.BackColor = Color.FromArgb(237, 27, 47);
            btnDisplayAppt.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDisplayAppt.ForeColor = SystemColors.Control;
            btnDisplayAppt.Location = new Point(87, 299);
            btnDisplayAppt.Name = "btnDisplayAppt";
            btnDisplayAppt.Size = new Size(266, 55);
            btnDisplayAppt.TabIndex = 3;
            btnDisplayAppt.Text = "Display Appointments";
            btnDisplayAppt.UseVisualStyleBackColor = false;
            btnDisplayAppt.Click += btnDisplayAppt_Click;
            // 
            // btnCancelAppt
            // 
            btnCancelAppt.BackColor = Color.FromArgb(237, 27, 47);
            btnCancelAppt.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCancelAppt.ForeColor = SystemColors.Control;
            btnCancelAppt.Location = new Point(87, 425);
            btnCancelAppt.Name = "btnCancelAppt";
            btnCancelAppt.Size = new Size(266, 55);
            btnCancelAppt.TabIndex = 4;
            btnCancelAppt.Text = "Cancel Appointment";
            btnCancelAppt.UseVisualStyleBackColor = false;
            btnCancelAppt.Click += btnCancelAppt_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(441, 179);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(872, 469);
            listBox1.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(237, 27, 47);
            label1.Font = new Font("Garamond", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(28, 9);
            label1.Name = "label1";
            label1.Size = new Size(93, 30);
            label1.TabIndex = 16;
            label1.Text = "McGill";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(237, 27, 47);
            pictureBox2.Location = new Point(-1, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(153, 49);
            pictureBox2.TabIndex = 15;
            pictureBox2.TabStop = false;
            // 
            // pbMenuBar
            // 
            pbMenuBar.BackColor = Color.Black;
            pbMenuBar.Location = new Point(-1, 0);
            pbMenuBar.Name = "pbMenuBar";
            pbMenuBar.Size = new Size(1412, 49);
            pbMenuBar.TabIndex = 14;
            pbMenuBar.TabStop = false;
            // 
            // FormMainMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1410, 721);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pbMenuBar);
            Controls.Add(listBox1);
            Controls.Add(btnCancelAppt);
            Controls.Add(btnDisplayAppt);
            Controls.Add(btnEligibility);
            Controls.Add(btnAddAppointment);
            Name = "FormMainMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Main Menu";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private Button btnAddAppointment;
        private Button btnEligibility;
        private Button btnDisplayAppt;
        private Button btnCancelAppt;
        private ListBox listBox1;
        public Label label1;
        private PictureBox pictureBox2;
        private PictureBox pbMenuBar;
    }
}
