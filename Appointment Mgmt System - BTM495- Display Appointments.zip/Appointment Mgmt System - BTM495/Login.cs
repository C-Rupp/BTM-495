﻿using Microsoft.Data.SqlClient;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPassword.Text;

            string userRole = ValidateUser(email, password);

            if (userRole != null)
            {
                MessageBox.Show("Login successful!", "Success");

                // Open appropriate form based on the user's role

                if (userRole == "Lab Coordinator")
                {
                    FormMainMenu formMainMenu = new FormMainMenu(email);
                    formMainMenu.Show();
                }
                else if (userRole == "Participant")
                {
                    FormParticipantView formParticipantView = new FormParticipantView(email);
                    formParticipantView.Show();
                }
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid email or password.", "Error");
            }
        }

        private string ValidateUser(string email, string password)
        {
            string connectionString = "Data Source=DESKTOP-MN\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Encrypt=True;Trust Server Certificate=True"; // Update with your SQL Server connection string
            string query = "SELECT Role FROM Users WHERE Email = @email AND password = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@Password", password);

                try
                {
                    connection.Open();
                    var role = command.ExecuteScalar() as string;
                    return role;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error");
                    return null;
                }
            }
        }

        private void lblUsername_Click(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCreateProfile_Click(object sender, EventArgs e)
        {
            FormCreateProfile formCreateProfile = new FormCreateProfile();
            this.Hide();
            formCreateProfile.ShowDialog();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}




