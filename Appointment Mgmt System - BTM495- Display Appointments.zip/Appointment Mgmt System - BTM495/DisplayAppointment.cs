﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormDisplayAppointment : Form
    {
        public FormDisplayAppointment()
        {
            InitializeComponent();
            PopulateMonths();
        }

        public void PopulateMonths()
        {
            // Make sure the combo box exists and is properly named
            if (cmbBoxMonth != null)
            {
                cmbBoxMonth.Items.AddRange(new string[]
                {
                    "January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"
                });

            }
        }

        private void cmbBoxMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbBoxMonth.SelectedItem != null)
            {
                MessageBox.Show($"You selected: {cmbBoxMonth.SelectedItem}");
            }
        }

        private void txtBoxYear_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBoxApp_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDisplayApp_Click(object sender, EventArgs e)
        {
            if (cmbBoxMonth.SelectedItem == null || string.IsNullOrWhiteSpace(txtBoxYear.Text))
            {
                MessageBox.Show("Please select a month and enter a year.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Convert month name to number
            int month = cmbBoxMonth.SelectedIndex + 1;

            // Parse year input
            if (!int.TryParse(txtBoxYear.Text, out int year))
            {
                MessageBox.Show("Please enter a valid numeric year.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Fetch data from the database
            FetchAppointments(month, year);
        }

        private void FetchAppointments(int month, int year)
        {
            string connectionString = "Data Source=DESKTOP-UM5GAQI\\SQLEXPRESS;Initial Catalog=\"BTM 495\";Integrated Security=True;Encrypt=True;";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // SQL Query to fetch data
                    string query = @"
                        SELECT 
                            u.FirstName, 
                            u.LastName, 
                            DATEDIFF(MONTH, GETDATE(), a.AppointmentDateStart) AS dateDiff
                        FROM 
                            Users u
                        INNER JOIN 
                            Appointments a ON u.UserID = a.UserID
                        WHERE 
                            MONTH(a.AppointmentDateStart) = @Month AND 
                            YEAR(a.AppointmentDateStart) = @Year";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Month", month);
                        command.Parameters.AddWithValue("@Year", year);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Clear previous results
                            listBoxApp.Items.Clear();

                            // Add table headers
                            listBoxApp.Items.Add("First Name\tLast Name\tDate Difference");

                            // Read results
                            while (reader.Read())
                            {
                                string? firstName = reader["FirstName"] != DBNull.Value ? reader["FirstName"].ToString() : "N/A";
                                string? lastName = reader["LastName"] != DBNull.Value ? reader["LastName"].ToString() : "N/A";
                                string? dateDiff = reader["dateDiff"] != DBNull.Value ? reader["dateDiff"].ToString() : "N/A";

                                // Add to ListBox
                                listBoxApp.Items.Add($"{firstName}\t{lastName}\t{dateDiff}");
                            }
                        }

                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static TextBox GetTxtBoxYear(TextBox txtBoxYear) => txtBoxYear;

        private static void TxtBoxYear_TextChanged1(object sender, EventArgs e, TextBox txtBoxYear)
        {
            // Check if the input is valid as the user types
            if (!string.IsNullOrWhiteSpace(txtBoxYear.Text) && !int.TryParse(txtBoxYear.Text, out _))
            {
                MessageBox.Show("Please enter only numeric values for the year.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBoxYear.Text = string.Empty;
            }
        }
    }
}

