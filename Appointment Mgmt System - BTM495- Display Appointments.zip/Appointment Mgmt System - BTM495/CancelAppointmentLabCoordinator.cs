﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class CancelAppointmentLabCoordinator : Form
    {
        private string participantEmail; // Store the email entered by the lab coordinator
        private int participantUserID; // Store the participant's userID after fetching from the database
        private int appointmentID; // Store the appointment ID for cancellation
        public CancelAppointmentLabCoordinator()
        {
            InitializeComponent();
        }

        // Button click event to fetch participant's appointment details based on email
        private void btnEnter_Click(object sender, EventArgs e)
        {
            participantEmail = txtParticipantEmail.Text; // Get the email entered by the lab coordinator

            if (!string.IsNullOrEmpty(participantEmail))
            {
                // Fetch the participant's userID and appointment details
                participantUserID = GetUserIDByEmail(participantEmail);

                if (participantUserID != -1)
                {
                    // Fetch and display the participant's appointment details
                    DisplayAppointmentDetails(participantUserID);
                }
                else
                {
                    MessageBox.Show("Participant with this email not found.", "Error");
                }
            }
            else
            {
                MessageBox.Show("Please enter a participant's email.", "Error");
            }
        }

        // Method to fetch the participant's userID based on email
        private int GetUserIDByEmail(string email)
        {
            int userID = -1; // Default to -1 if user not found

            try
            {
                using (SqlConnection conn = new SqlConnection("your_connection_string"))
                {
                    string query = "SELECT userID FROM Users WHERE email = @Email";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Email", email);

                    conn.Open();
                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        userID = Convert.ToInt32(result);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching user ID: {ex.Message}", "Error");
            }

            return userID;
        }

        // Method to fetch and display the participant's appointment details
        private void DisplayAppointmentDetails(int userID)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("your_connection_string"))
                {
                    string query = "SELECT appointmentID, appointmentDateStart, appointmentDateEnd, room, status " +
                                   "FROM Appointment WHERE userID = @UserID AND status != 'canceled'";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@UserID", userID);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Populate the read-only textbox with appointment details
                        appointmentID = Convert.ToInt32(reader["appointmentID"]);
                        string appointmentDetails = $"Appointment ID: {appointmentID}\n" +
                                                    $"Start Time: {reader["appointmentDateStart"]}\n" +
                                                    $"End Time: {reader["appointmentDateEnd"]}\n" +
                                                    $"Room: {reader["room"]}\n" +
                                                    $"Status: {reader["status"]}";

                        txtAppointmentDetailsLC.Text = appointmentDetails;
                    }
                    else
                    {
                        MessageBox.Show("No active appointments found for this participant.", "Error");
                        txtAppointmentDetailsLC.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching appointment details: {ex.Message}", "Error");
            }
        }
        // Button click event to confirm appointment cancellation
        private void btnConfirmCancel_Click(object sender, EventArgs e)
        {
            if (appointmentID != 0)
            {
                try
                {
                    // Call the method to cancel the appointment
                    CancelAppointment(appointmentID);

                    // Show a success message
                    MessageBox.Show("The appointment has been canceled.", "Success");

                }

                catch (Exception ex)
                {
                    // Handle any errors that occur during the cancellation process
                    MessageBox.Show($"Error during cancellation: {ex.Message}", "Error");
                }
            }
            else
            {
                // If appointmentID is invalid, show an error message
                MessageBox.Show("No appointment selected to cancel.", "Error");
            }
        }

        // Method to cancel the appointment
        private void CancelAppointment(int appointmentID)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("your_connection_string"))
                {
                    string query = "UPDATE Appointment SET status = 'canceled', cancellationDate = @CancellationDate " +
                                   "WHERE appointmentID = @AppointmentID";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@CancellationDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@AppointmentID", appointmentID);

                    conn.Open();
                    cmd.ExecuteNonQuery(); // Execute the update query to cancel the appointment
                }
            }
            catch (Exception ex)
            {
                // Handle any errors during database operation
                MessageBox.Show($"Error canceling appointment: {ex.Message}", "Error");
            }
        }

        // Button click event to save the cancellation request for later
        private void btnSaveForLater_Click(object sender, EventArgs e)
        {
            // You can implement a feature to save the cancellation for later, such as storing the request
            // in a database or a separate table to be reviewed by the lab coordinator at a later time.
            MessageBox.Show("The cancellation request has been saved for later.", "Saved");
        }
    

    private void InitializeComponent()
        {
            pbMenuBar = new PictureBox();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            lblEmail = new Label();
            txtParticipantEmail = new TextBox();
            txtAppointmentDetailsLC = new TextBox();
            btnSaveForLaterLC = new Button();
            btnConfirmCancelLC = new Button();
            lblDetailsLC = new Label();
            btnEnter = new Button();
            ((ISupportInitialize)pbMenuBar).BeginInit();
            ((ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // pbMenuBar
            // 
            pbMenuBar.BackColor = Color.Black;
            pbMenuBar.Location = new Point(0, 0);
            pbMenuBar.Margin = new Padding(5);
            pbMenuBar.Name = "pbMenuBar";
            pbMenuBar.Size = new Size(2219, 78);
            pbMenuBar.TabIndex = 15;
            pbMenuBar.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(237, 27, 47);
            label1.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(46, 14);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(143, 47);
            label1.TabIndex = 18;
            label1.Text = "McGill";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(237, 27, 47);
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Margin = new Padding(5);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(240, 78);
            pictureBox2.TabIndex = 17;
            pictureBox2.TabStop = false;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEmail.ForeColor = Color.Black;
            lblEmail.Location = new Point(722, 172);
            lblEmail.Margin = new Padding(5, 0, 5, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(208, 32);
            lblEmail.TabIndex = 24;
            lblEmail.Text = "Participant Email";
            lblEmail.Click += lblSelect_Click;
            // 
            // txtParticipantEmail
            // 
            txtParticipantEmail.Font = new Font("Segoe UI", 10F);
            txtParticipantEmail.Location = new Point(618, 251);
            txtParticipantEmail.Margin = new Padding(5);
            txtParticipantEmail.Name = "txtParticipantEmail";
            txtParticipantEmail.Size = new Size(211, 34);
            txtParticipantEmail.TabIndex = 25;
            txtParticipantEmail.TextChanged += txtEmail_TextChanged;
            // 
            // txtAppointmentDetailsLC
            // 
            txtAppointmentDetailsLC.Location = new Point(618, 384);
            txtAppointmentDetailsLC.Multiline = true;
            txtAppointmentDetailsLC.Name = "txtAppointmentDetailsLC";
            txtAppointmentDetailsLC.ReadOnly = true;
            txtAppointmentDetailsLC.Size = new Size(385, 198);
            txtAppointmentDetailsLC.TabIndex = 26;
            txtAppointmentDetailsLC.TextChanged += txtAppointmentDetailsLC_TextChanged;
            // 
            // btnSaveForLaterLC
            // 
            btnSaveForLaterLC.BackColor = Color.FromArgb(237, 27, 47);
            btnSaveForLaterLC.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSaveForLaterLC.ForeColor = SystemColors.Control;
            btnSaveForLaterLC.Location = new Point(873, 679);
            btnSaveForLaterLC.Margin = new Padding(5);
            btnSaveForLaterLC.Name = "btnSaveForLaterLC";
            btnSaveForLaterLC.Size = new Size(541, 67);
            btnSaveForLaterLC.TabIndex = 28;
            btnSaveForLaterLC.Text = "Save for Later";
            btnSaveForLaterLC.UseVisualStyleBackColor = false;
            btnSaveForLaterLC.Click += btnSaveForLaterLC_Click;
            // 
            // btnConfirmCancelLC
            // 
            btnConfirmCancelLC.BackColor = Color.FromArgb(237, 27, 47);
            btnConfirmCancelLC.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnConfirmCancelLC.ForeColor = SystemColors.Control;
            btnConfirmCancelLC.Location = new Point(245, 679);
            btnConfirmCancelLC.Margin = new Padding(5);
            btnConfirmCancelLC.Name = "btnConfirmCancelLC";
            btnConfirmCancelLC.Size = new Size(541, 67);
            btnConfirmCancelLC.TabIndex = 27;
            btnConfirmCancelLC.Text = "Confirm Cancel";
            btnConfirmCancelLC.UseVisualStyleBackColor = false;
            btnConfirmCancelLC.Click += btnConfirmCancelLC_Click;
            // 
            // lblDetailsLC
            // 
            lblDetailsLC.AutoSize = true;
            lblDetailsLC.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDetailsLC.ForeColor = Color.Black;
            lblDetailsLC.Location = new Point(691, 321);
            lblDetailsLC.Margin = new Padding(5, 0, 5, 0);
            lblDetailsLC.Name = "lblDetailsLC";
            lblDetailsLC.Size = new Size(251, 32);
            lblDetailsLC.TabIndex = 29;
            lblDetailsLC.Text = "Appointment Details";
            // 
            // btnEnter
            // 
            btnEnter.BackColor = Color.FromArgb(237, 27, 47);
            btnEnter.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEnter.ForeColor = SystemColors.Control;
            btnEnter.Location = new Point(852, 235);
            btnEnter.Margin = new Padding(5);
            btnEnter.Name = "btnEnter";
            btnEnter.Size = new Size(163, 67);
            btnEnter.TabIndex = 30;
            btnEnter.Text = "Enter";
            btnEnter.UseVisualStyleBackColor = false;
            // 
            // CancelAppointmentLabCoordinator
            // 
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(2166, 1137);
            Controls.Add(btnEnter);
            Controls.Add(lblDetailsLC);
            Controls.Add(btnSaveForLaterLC);
            Controls.Add(btnConfirmCancelLC);
            Controls.Add(txtAppointmentDetailsLC);
            Controls.Add(txtParticipantEmail);
            Controls.Add(lblEmail);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pbMenuBar);
            Name = "CancelAppointmentLabCoordinator";
            ((ISupportInitialize)pbMenuBar).EndInit();
            ((ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void lblSelect_Click(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnConfirmCancelLC_Click(object sender, EventArgs e)
        {

        }

        private void txtAppointmentDetailsLC_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSaveForLaterLC_Click(object sender, EventArgs e)
        {

        }
    }
}
