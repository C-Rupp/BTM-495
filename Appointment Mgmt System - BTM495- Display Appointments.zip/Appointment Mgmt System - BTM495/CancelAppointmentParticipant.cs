﻿using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormCancelAppointment : Form
    {
        private string connectionString = "our_connection_string_here";
        private int loggedInUserID; // Assume this is set when the user logs in
        public FormCancelAppointment(int userID)
        {
            InitializeComponent();
            loggedInUserID = userID;// Assign the userID to the class variable
        }

        private void CancelAppointmentForm_Load(object sender, EventArgs e)
        {
            // Fetch and populate participant's appointments
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string fetchQuery = @"
                SELECT appointmentID, appointmentDateStart 
                FROM Appointment
                WHERE userID = @userID AND status = 'Scheduled' AND appointmentDateStart > GETDATE()";

                SqlCommand cmd = new SqlCommand(fetchQuery, conn);
                cmd.Parameters.AddWithValue("@userID", loggedInUserID);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable appointments = new DataTable();
                adapter.Fill(appointments);

                cmbAppointments.DataSource = appointments;
                cmbAppointments.DisplayMember = "appointmentDateStart"; // Display appointment start time
                cmbAppointments.ValueMember = "appointmentID"; // Use appointmentID as the value
            }
        }

        private void cmbAppointments_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbAppointments.SelectedValue != null)
            {
                int selectedAppointmentID = Convert.ToInt32(cmbAppointments.SelectedValue);// Fetch appointment details

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string detailsQuery = @"
                    SELECT appointmentDateStart, appointmentDateEnd, room, detail 
                    FROM Appointment
                    WHERE appointmentID = @appointmentID";

                    SqlCommand cmd = new SqlCommand(detailsQuery, conn);
                    cmd.Parameters.AddWithValue("@appointmentID", selectedAppointmentID);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        string details = $"Start Time: {reader.GetDateTime(reader.GetOrdinal("appointmentDateStart"))}\n" +
                                         $"End Time: {reader.GetDateTime(reader.GetOrdinal("appointmentDateEnd"))}\n" +
                                         $"Room: {reader.GetString(reader.GetOrdinal("room"))}\n" +
                                         $"Details: {reader.GetString(reader.GetOrdinal("detail"))}";

                        txtAppointmentDetails.Text = details;
                    }
                    else
                    {
                        txtAppointmentDetails.Text = "No details available for the selected appointment.";
                    }
                }
            }
        }
        private void btnConfirmCancel_Click(object sender, EventArgs e)
        {
            if (cmbAppointments.SelectedItem == null)
            {
                MessageBox.Show("Please select an appointment to cancel.");
                return;
            }

            int selectedAppointmentID = Convert.ToInt32(cmbAppointments.SelectedValue);

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    // Step 1: Check the time difference
                    string checkQuery = @"
                    SELECT DATEDIFF(HOUR, GETDATE(), appointmentDateStart) AS HoursDifference, status
                    FROM Appointment
                    WHERE appointmentID = @appointmentID AND userID = @userID";

                    SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                    checkCmd.Parameters.AddWithValue("@appointmentID", selectedAppointmentID);
                    checkCmd.Parameters.AddWithValue("@userID", loggedInUserID);

                    SqlDataReader reader = checkCmd.ExecuteReader();

                    if (reader.Read())
                    {
                        int hoursDifference = reader.GetInt32(reader.GetOrdinal("HoursDifference"));
                        string status = reader.GetString(reader.GetOrdinal("status"));

                        if (status != "Scheduled")
                        {
                            MessageBox.Show("The selected appointment is not scheduled and cannot be canceled.", "Invalid Action");
                            return;
                        }

                        reader.Close(); // Close the reader before proceeding

                        if (hoursDifference > 24)
                        {
                            // Step 2: Update the appointment status
                            string updateQuery = @"
                            UPDATE Appointment
                            SET status = 'Canceled', cancellationDate = GETDATE()
                            WHERE appointmentID = @appointmentID";

                            SqlCommand updateCmd = new SqlCommand(updateQuery, conn);
                            updateCmd.Parameters.AddWithValue("@appointmentID", selectedAppointmentID);

                            int rowsAffected = updateCmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("The selected appointment has been canceled.", "Success");
                            }
                            else
                            {
                                MessageBox.Show("Failed to cancel the appointment. Please try again.", "Error");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please contact the lab coordinator as it's less than 24 hours before the appointment.", "Action Required");
                        }
                    }
                    else
                    {
                        MessageBox.Show("The selected appointment does not exist or you are not authorized to cancel it.", "Error");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error");
            }
        }

        private void btnSaveForLater_Click(object sender, EventArgs e)
        {
            // Save for later functionality
            MessageBox.Show("Please select an appointment if you would still like to cancel an appintment later. Thank you!");
        }

        private void txtAppointmentDetails_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void FormCancelAppointment_Load(object sender, EventArgs e)
        {

        }
    }
}
