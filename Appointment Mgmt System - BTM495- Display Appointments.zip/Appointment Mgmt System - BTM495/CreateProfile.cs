﻿using Microsoft.Data.SqlClient;
using System;
using System.Windows.Forms;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormCreateProfile : Form
    {
        public FormCreateProfile()
        {
            InitializeComponent();
        }

        private void btnCreateProfile_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=DESKTOP-MN\\SQLEXPRESS;Initial Catalog=\"BTM495 DB\";Integrated Security=True;Encrypt=True;Trust Server Certificate=True";

                // Initialize user ID
                int newUserID;

                // Fetch the highest existing userID from the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string getMaxIDQuery = "SELECT ISNULL(MAX(userID), 0) FROM [dbo].[Users]";
                    using (SqlCommand command = new SqlCommand(getMaxIDQuery, connection))
                    {
                        int maxID = Convert.ToInt32(command.ExecuteScalar());
                        newUserID = maxID + 1; // Increment the max ID to generate the new user ID
                    }
                }

                // Initialize participant ID
                int newParticipantID;

                // Fetch the highest existing participantID from the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string getMaxIDQuery = "SELECT ISNULL(MAX(participantID), 0) FROM [dbo].[Participant]";
                    using (SqlCommand command = new SqlCommand(getMaxIDQuery, connection))
                    {
                        int maxID = Convert.ToInt32(command.ExecuteScalar());
                        newParticipantID = maxID + 1; // Increment the max ID to generate the new participant ID
                    }
                }

                // Insert user and participant into the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    {
                        try
                        {
                            string insertUserQuery = @"
                                INSERT INTO [dbo].[Users] 
                                (userID, firstName, lastName, role, email, password) 
                                VALUES 
                                (@UserID, @FirstName, @LastName, @Role, @Email, @Password)";

                            string insertParticipantQuery = @"
                                INSERT INTO [dbo].[Participant]
                                (participantID, userID, gender, dateOfBirth, height, weight, emergencyContactName, emergencyContactPhone, eligibilityStatus) 
                                VALUES
                                (@ParticipantID, @UserID, @Gender, @DateOfBirth, @Height, @Weight, @EmergencyContactName, @EmergencyContactPhone, @EligibilityStatus);";

                            using (SqlCommand insertUserCommand = new SqlCommand(insertUserQuery, connection))
                            {
                                insertUserCommand.Parameters.AddWithValue("@UserID", newUserID);
                                insertUserCommand.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                                insertUserCommand.Parameters.AddWithValue("@LastName", txtLastName.Text);
                                insertUserCommand.Parameters.AddWithValue("@Role", "Participant");
                                insertUserCommand.Parameters.AddWithValue("@Email", txtEmail.Text);

                                if (txtPassword.Text == txtConfirmPassword.Text)
                                {
                                    insertUserCommand.Parameters.AddWithValue("@Password", txtPassword.Text);
                                }
                                else
                                {
                                    MessageBox.Show("Passwords are not matching");
                                    return; // Exit the method if passwords do not match
                                }

                                insertUserCommand.ExecuteNonQuery();
                            }

                            using (SqlCommand insertParticipantCommand = new SqlCommand(insertParticipantQuery, connection))
                            {
                                insertParticipantCommand.Parameters.AddWithValue("@ParticipantID", newParticipantID);
                                insertParticipantCommand.Parameters.AddWithValue("@UserID", newUserID);
                                insertParticipantCommand.Parameters.AddWithValue("@Gender", txtGender.Text);
                                insertParticipantCommand.Parameters.AddWithValue("@DateOfBirth", dtpDateOfBirth.Value);
                                insertParticipantCommand.Parameters.AddWithValue("@Weight", int.Parse(txtWeight.Text));
                                insertParticipantCommand.Parameters.AddWithValue("@Height", int.Parse(txtHeight.Text));
                                insertParticipantCommand.Parameters.AddWithValue("@EmergencyContactName", txtEmergencyContactName.Text);
                                insertParticipantCommand.Parameters.AddWithValue("@EmergencyContactPhone", txtEmergencyContactPhone.Text);
                                insertParticipantCommand.Parameters.AddWithValue("@EligibilityStatus", DBNull.Value);

                                insertParticipantCommand.ExecuteNonQuery();
                            }
                            MessageBox.Show($"Profile has been created: Use {txtEmail.Text} and {txtPassword.Text} to log in");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"An error occurred: {ex.Message}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
