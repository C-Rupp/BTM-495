﻿namespace Appointment_Mgmt_System___BTM495
{
    public class Participant : User
    {
        public decimal Weight { get; set; }
        public decimal Height { get; set; }
        public string EmergencyContactName { get; set; }
        public string EmergencyContactPhone { get; set; }
        public bool EligibilityStatus { get; set; }

        public Participant(int userID, string firstName, string lastName, string email,
                           decimal weight, decimal height,
                           string emergencyContactName, string emergencyContactPhone, bool eligibilityStatus)
            : base(userID, firstName, lastName, email)
        {
            Weight = weight;
            Height = height;
            EmergencyContactName = emergencyContactName;
            EmergencyContactPhone = emergencyContactPhone;
            EligibilityStatus = eligibilityStatus;
        }
    }
}
