﻿namespace Appointment_Mgmt_System___BTM495
{
    partial class FormCancelAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pbMenuBar = new PictureBox();
            cmbAppointments = new ComboBox();
            txtAppointmentDetails = new TextBox();
            btnConfirmCancel = new Button();
            btnSaveForLater = new Button();
            lblSelect = new Label();
            pictureBox2 = new PictureBox();
            lblDetail = new Label();
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(237, 27, 47);
            label1.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(44, 14);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(143, 47);
            label1.TabIndex = 16;
            label1.Text = "McGill";
            // 
            // pbMenuBar
            // 
            pbMenuBar.BackColor = Color.Black;
            pbMenuBar.Location = new Point(-2, 0);
            pbMenuBar.Margin = new Padding(5);
            pbMenuBar.Name = "pbMenuBar";
            pbMenuBar.Size = new Size(2219, 78);
            pbMenuBar.TabIndex = 14;
            pbMenuBar.TabStop = false;
            // 
            // cmbAppointments
            // 
            cmbAppointments.FormattingEnabled = true;
            cmbAppointments.Location = new Point(504, 272);
            cmbAppointments.Name = "cmbAppointments";
            cmbAppointments.Size = new Size(387, 32);
            cmbAppointments.TabIndex = 18;
            cmbAppointments.SelectedIndexChanged += cmbAppointments_SelectedIndexChanged;
            // 
            // txtAppointmentDetails
            // 
            txtAppointmentDetails.Location = new Point(504, 411);
            txtAppointmentDetails.Multiline = true;
            txtAppointmentDetails.Name = "txtAppointmentDetails";
            txtAppointmentDetails.ReadOnly = true;
            txtAppointmentDetails.Size = new Size(387, 189);
            txtAppointmentDetails.TabIndex = 19;
            txtAppointmentDetails.TextChanged += txtAppointmentDetails_TextChanged;
            // 
            // btnConfirmCancel
            // 
            btnConfirmCancel.BackColor = Color.FromArgb(237, 27, 47);
            btnConfirmCancel.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnConfirmCancel.ForeColor = SystemColors.Control;
            btnConfirmCancel.Location = new Point(116, 746);
            btnConfirmCancel.Margin = new Padding(5);
            btnConfirmCancel.Name = "btnConfirmCancel";
            btnConfirmCancel.Size = new Size(541, 67);
            btnConfirmCancel.TabIndex = 20;
            btnConfirmCancel.Text = "Confirm Cancel";
            btnConfirmCancel.UseVisualStyleBackColor = false;
            // 
            // btnSaveForLater
            // 
            btnSaveForLater.BackColor = Color.FromArgb(237, 27, 47);
            btnSaveForLater.Font = new Font("Segoe UI Black", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSaveForLater.ForeColor = SystemColors.Control;
            btnSaveForLater.Location = new Point(744, 746);
            btnSaveForLater.Margin = new Padding(5);
            btnSaveForLater.Name = "btnSaveForLater";
            btnSaveForLater.Size = new Size(541, 67);
            btnSaveForLater.TabIndex = 21;
            btnSaveForLater.Text = "Save for Later";
            btnSaveForLater.UseVisualStyleBackColor = false;
            // 
            // lblSelect
            // 
            lblSelect.AutoSize = true;
            lblSelect.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSelect.ForeColor = Color.Black;
            lblSelect.Location = new Point(570, 207);
            lblSelect.Margin = new Padding(5, 0, 5, 0);
            lblSelect.Name = "lblSelect";
            lblSelect.Size = new Size(275, 32);
            lblSelect.TabIndex = 23;
            lblSelect.Text = "Select an Appointment";
            lblSelect.Click += label2_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(237, 27, 47);
            pictureBox2.Location = new Point(-2, 0);
            pictureBox2.Margin = new Padding(5);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(240, 78);
            pictureBox2.TabIndex = 15;
            pictureBox2.TabStop = false;
            // 
            // lblDetail
            // 
            lblDetail.AutoSize = true;
            lblDetail.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDetail.ForeColor = Color.Black;
            lblDetail.Location = new Point(570, 349);
            lblDetail.Margin = new Padding(5, 0, 5, 0);
            lblDetail.Name = "lblDetail";
            lblDetail.Size = new Size(251, 32);
            lblDetail.TabIndex = 24;
            lblDetail.Text = "Appointment Details";
            // 
            // FormCancelAppointment
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(2216, 1154);
            Controls.Add(lblDetail);
            Controls.Add(lblSelect);
            Controls.Add(btnSaveForLater);
            Controls.Add(btnConfirmCancel);
            Controls.Add(txtAppointmentDetails);
            Controls.Add(cmbAppointments);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pbMenuBar);
            Margin = new Padding(5);
            Name = "FormCancelAppointment";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Appointment Cancellation";
            Load += FormCancelAppointment_Load;
            ((System.ComponentModel.ISupportInitialize)pbMenuBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        public Label label1;
        private PictureBox pbMenuBar;
        private ComboBox cmbAppointments;
        private TextBox txtAppointmentDetails;
        private Button btnConfirmCancel;
        private Button btnSaveForLater;
        public Label lblSelect;
        private PictureBox pictureBox2;
        public Label lblDetail;
    }
}