﻿using Microsoft.Data.SqlClient;

namespace Appointment_Mgmt_System___BTM495
{
    public partial class FormParticipantView : Form
    {

        private string email;

        public FormParticipantView(string email)
        {
            InitializeComponent();
            this.email = email;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //created by accident don't delete or it will caused errors
        }

        private void btnCancelAppt_Click(object sender, EventArgs e)
        {
            // Fetch the userID using the email
            int userID = GetUserIDByEmail(email);

            if (userID != -1)
            {
                // Open the CancelAppointmentForm and pass the userID
                FormCancelAppointment cancelForm = new FormCancelAppointment(userID);
                cancelForm.ShowDialog(); // Show as a modal dialog
            }
            else
            {
                MessageBox.Show("User not found.", "Error");
            }
        }
        // Method to fetch the userID based on the email
        private int GetUserIDByEmail(string email)
        {
            // Assuming you have a method to query the database and fetch userID by email
            // Adjust the database query to your needs
            int userID = -1; // Default to -1 (user not found)

            try
            {
                using (SqlConnection conn = new SqlConnection("your_connection_string"))
                {
                    string query = "SELECT userID FROM Users WHERE email = @Email";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Email", email);

                    conn.Open();
                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        userID = Convert.ToInt32(result);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching user ID: {ex.Message}", "Error");
            }

            return userID;
        }
    }
}
